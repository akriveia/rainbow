$(function(){
	setTimeout(function(){
		$(".modal").addClass("in");
		$(".modal").show();
    }, 8000);
	$(".enquire-close").click(function(){
		$(".modal").removeClass("in");
		$(".modal").hide();
	});
	//$("#choose-course").select2();
	//$("#choose-branch").select2();
	$("#register-now").click(function(e){
		e.preventDefault();
		$("#register-now").attr("disabled",true);
		$.ajax({
			type:"post",
			url:baseurl + "save-popup-enquiry",
			data:$("#enquiry-form").serialize() + '&url=' + window.location.href,
			dataType:"json",
			success:function(data){
				if(data.success == 1)
				{
					location.href= baseurl + "thank-you"
				}
				else{
					$("#form-error").text(data.error);
					if($("#form-error").text().length > 0) {
						setTimeout(function() {
							$("#form-error").text('', {}, 1000);
							$("#register-now").attr("disabled",false);
						}, 1000);
					}
				}
			}
		});
	});
	$("#enquiry-now").click(function(e){
		e.preventDefault();
		$("#enquiry-now").attr("disabled", "disabled");
		$.ajax({
			type:"post",
			url:baseurl + "save-enquiry",
			data:$("#side-enquiry-form").serialize() + '&url=' + window.location.href,
			dataType:"json",
			success:function(data){
				if(data.success == 1)
				{
					location.href= baseurl + "thank-you"
				}
				else{
					$("#form-error").text(data.error);
					if($("#form-error").text().length > 0) {
						setTimeout(function() {
							$("#form-error").text('', {}, 1000);
							$("#enquiry-now").attr("disabled",false);
						}, 1000);
					}
				}
			}
		});
	});
	$("#submit-contact").click(function(e){
		e.preventDefault();
		$("#submit-contact").attr("disabled",true);
		$.ajax({
			type:"post",
			url:baseurl + "save-contact",
			data:$("#contact-form").serialize() + '&url=' + window.location.href,
			dataType:"json",
			success:function(data){
				if(data.success == 1)
				{
					location.href= baseurl + "thank-you"
				}
				else{
					$("#form-error").text(data.error);
					if($("#form-error").text().length > 0) {
						setTimeout(function() {
							$("#form-error").text('', {}, 1000);
							$("#submit-contact").attr("disabled",false);;
						}, 1000);
					}
				}
			}
		});
	});
});