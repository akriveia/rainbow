<!doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow  | Coming Soon</title>
		<?php include_once("head-styles.php");?>
    </head>
	<body>
        <div id="wrapper">
			<?php
				$tab = "index";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/crum-bg2.jpg');background-repeat:repeat">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>Coming Soon</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Coming Soon</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="error-page-area" style="background:#F9FAFC">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="error-top">
                                <img src="<?php echo BASEURL;?>assets/images/coming-soon.jpg" class="img-responsive" alt="Coming SOon">
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="error-bottom">
                                <p>We are working on this page and will be available soon. Visit our Home Page by using the button below.</p>
                                <a href="<?php echo BASEURL;?>" class="view-all-accent-btn">Go To Home Page</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>