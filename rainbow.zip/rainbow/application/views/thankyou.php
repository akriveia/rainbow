<!doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow  | Thank You</title>
		<?php include_once("head-styles.php");?>
    </head>
	<body>
        <div id="wrapper">
			<?php
				$tab = "index";
				include_once("menu.php");
			?>
            <div class="error-page-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="error-bottom">                                
                                <h2>Thank you for contacting us. We will get back to you soon.</h2>
                                <a href="<?php echo BASEURL;?>" class="default-white-btn mt10">Go To Home Page</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
		<!-- Event snippet for Leads conversion page -->
		<script>
		  gtag('event', 'conversion', {'send_to': 'AW-827928312/ovssCJSMuHwQ-N3kigM'});
		</script>
    </body>
</html>