<footer>
				<div class="footer-area-top">
					<div class="container">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
								<div class="footer-box">
									<h3>About us</h3>
									<div class="footer-about">
										<p>Rainbow will be a world leader in preparing professionals who provide leadership and exemplary educational and related services to improve the lives of individuals in a changing and complex global society.</p>
									</div>
									<ul class="footer-social">
										<li><a target="_blank" href="https://www.facebook.com/rainbowinstitution/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a target="_blank" href="https://www.linkedin.com/company/rainbow-institutions"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a target="_blank" href="https://plus.google.com/u/3/105787695468463653260"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
								<div class="footer-box">
									<h3>Quick Links</h3>
									<ul class="featured-links">
										<li>
											<ul>
												<li><a href="<?php echo BASEURL;?>privacy-policy">Privacy Policy</a></li>
												<li><a href="<?php echo BASEURL;?>careers">Careers</a></li>
												<li><a href="<?php echo BASEURL;?>admission">Admission</a></li>
												<li><a href="#">Blog</a></li>
											</ul>
										</li>
										<li>
											<ul>
												<li><a href="<?php echo BASEURL;?>courses">Courses</a></li>
												<li><a href="<?php echo BASEURL;?>about-us">About Us</a></li>
												<li><a href="#">News & Updates</a></li>
												<li><a href="<?php echo BASEURL;?>contact-us">Contact Us</a></li>
											</ul>
										</li>
									</ul>                             
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
								<div class="footer-box">
									<h3>get in touch</h3>
									<ul class="corporate-address">
										<li><i class="fa fa-map-marker"></i><p>2nd floor, Venkateshwara complex,</p><p>Devasandra main road, Near GEETHA clinic,</p><p> K R Puram, Bengaluru - 560036</p></li>
										<li><i class="fa fa-map-marker"></i><p>#44, Leelavathi Achar Complex,</p><p>Immadihalli Main Rd, Near RAM Mandir,</p><p> Whitefield, Bengaluru - 560066</p></li>
										<li><i class="fa fa-phone"></i><a href="tel:97315 08686">97315 08686</a> / <a href="tel:97315 63656">97315 63656</a></li>
										<li><i class="fa fa-envelope-o"></i><a href="mailto:rainbowinstitution@gmail.com">rainbowinstitution@gmail.com</a></li>
									</ul>                                   
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-area-bottom">
					<div class="container">
						<div class="row">
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
								<p>Copyright &copy; 2015 Rainbow Institutions - All Rights Reserved</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
