<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Our Departments</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "depart";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/crum-bg.jpg');background-repeat:repeat">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>Our Departments</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Our Departments</li>
							</ul>
						</div>
                    </div>
                </div>
            </div>
            <div class="research-page2-area">
                <div class="container">
                    <div class="row"> 
                        <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="research-box2 text-justify"> 
									<div class="research-img-holder">                                 
										<a href="<?php echo BASEURL;?>tenth-department"><img src="<?php echo BASEURL;?>assets/images/course-1.jpg" alt="" class="img-responsive"></a>
										<div class="research-details">                                 
											<a href="<?php echo BASEURL;?>tenth-department">Tenth Standard<i class="fa fa-angle-right" aria-hidden="true"></i></a>
										</div>               
									</div>
									<p>The Department aims to equip children with specified knowledge, skills and values to enable them to become good human beings, productive and responsible citizens.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="research-box2 text-justify"> 
									<div class="research-img-holder">                                 
										<a href="<?php echo BASEURL;?>science-department"><img src="<?php echo BASEURL;?>assets/images/sci-dept.jpg" alt="" class="img-responsive"></a>
										<div class="research-details">                                 
											<a href="<?php echo BASEURL;?>science-department">Science<i class="fa fa-angle-right" aria-hidden="true"></i></a>
										</div>               
									</div>
									<p>The Department of science continuously strive to nurture the wonder and curiosity of the student and to help students to explore and use scientific methods of enquiry.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="research-box2 text-justify"> 
									<div class="research-img-holder">                                 
										<a href="<?php echo BASEURL;?>commerce-department"><img src="<?php echo BASEURL;?>assets/images/comm-dept.jpg" alt="" class="img-responsive"></a>
										<div class="research-details">                                 
											<a href="<?php echo BASEURL;?>commerce-department">Commerce<i class="fa fa-angle-right" aria-hidden="true"></i></a>
										</div>               
									</div>
									<p>The Department aims to nurture the commerce professionals with a high level of knowledge and competence to effectively contribute to society.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="research-box2 text-justify"> 
									<div class="research-img-holder">                                 
										<a href="<?php echo BASEURL;?>engineering-department"><img src="<?php echo BASEURL;?>assets/images/eng-dept.jpg" alt="" class="img-responsive"></a>
										<div class="research-details">                                 
											<a href="<?php echo BASEURL;?>engineering-department">Engineering & Diploma<i class="fa fa-angle-right" aria-hidden="true"></i></a>
										</div>               
									</div>
									<p>The Department aims to employ the mathematical and scientific principles to develop effective solutions to real-world, technical problems.</p>
								</div>
							</div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                            <?php include('side-enquiry.php');?>
                        </div>                
                    </div>
                </div>
            </div>
           <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>