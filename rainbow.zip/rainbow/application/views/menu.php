<header>                
				<div id="header2" class="header2-area">
					<div class="header-top-area">
						<div class="container">
							<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="header-top-left">
										<ul>
											<li><i class="fa fa-phone" aria-hidden="true"></i><a href="Tel:+91 97315 08686"> +91 97315 08686 </a></li>
											<li><i class="fa fa-phone" aria-hidden="true"></i><a href="Tel:+91 97315 63656"> +91 97315 63656 </a></li>
											<li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:rainbowinstitution@gmail.com">rainbowinstitution@gmail.com</a></li>
										</ul>
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 hidden">
									<div class="header-top-right">
										<ul>
											<li><a href="<?php echo BASEURL;?>careers"><i class="fa fa-graduation-cap" aria-hidden="true"></i> Careers</a></li>
											<li>
												<a class="login-btn-area" href="#" id="login-button"><i class="fa fa-lock" aria-hidden="true"></i> Login</a>
												<div class="login-form wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.3s" id="login-form" style="display: none;">
													<h1 class="title-default-left-bold">Login</h1>
												   <form>
														<input type="text" placeholder="Username"/>
														<input type="password" placeholder="Password"/>
														<label class="check"><a href="forgot-password">Forgot Password?</a></label>
														<button class="join-now-btn pull-right" type="submit" value="Login">Login</button>
													</form>
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="main-menu-area bg-textPrimary" id="sticker">
						<div class="container">
							<div class="row">                         
								<div class="col-lg-2 col-md-2 col-sm-3">
									<div class="logo-area">
										<a href="<?php echo BASEURL;?>"><img src="<?php echo BASEURL;?>assets/images/logo.png" alt="Rainbow"></a>
									</div>
								</div>  
								<div class="col-lg-10 col-md-10 col-sm-9">
									<nav>
										<ul>
											<li <?php if($tab == "index") echo 'class=active';?>><a href="<?php echo BASEURL;?>">Home</a></li>
											<li <?php if($tab == "about") echo 'class=active';?>><a href="<?php echo BASEURL;?>about-us">About Us</a>
												<ul class="hidden">
													<li><a href="<?php echo BASEURL;?>about-us">Overview</a></li>
													<li><a href="<?php echo BASEURL;?>about-us#mission-vision">Mission & Vision</a></li>
													<li><a href="<?php echo BASEURL;?>about-us#facilities">Facilities Offered</a></li>
													<li><a href="<?php echo BASEURL;?>about-us#our-team">Our Team</a></li>
												</ul>
											</li>
											<li <?php if($tab == "courses") echo 'class=active';?>><a href="<?php echo BASEURL;?>courses">Courses <i class="fa fa-angle-down" aria-hidden="true"></i></a>
												<ul class="mega-menu-area">
													<li>
														<a href="<?php echo BASEURL;?>tenth-standard">10<sup style="text-transform:lowercase">th</sup> Standard</a>
														<a href="<?php echo BASEURL;?>puc-science">I-II PUC Science</a>
														<a href="<?php echo BASEURL;?>puc-commerce">I-II PUC Commerce</a>
													</li>
													<li>
														<a href="<?php echo BASEURL;?>cet">NEET/ JEE/ K-CET/ COMED-K</a>
														<a href="<?php echo BASEURL;?>bcom-bbm">B.Com & BBM</a>
														<a href="<?php echo BASEURL;?>diploma">Diploma</a>
													</li>
													<li>
														<a href="<?php echo BASEURL;?>engineering">Engineering</a>
														<a href="<?php echo BASEURL;?>ca-cpt">CA-CPT</a>
														<a href="<?php echo BASEURL;?>cs-cma">CS-CMA</a>
													</li>
												</ul>                                           
											</li>
											<li <?php if($tab == "depart") echo 'class=active';?>><a href="<?php echo BASEURL;?>departments">Departments <i class="fa fa-angle-down" aria-hidden="true"></i></a>
												<ul>
													<li><a href="<?php echo BASEURL;?>science-department">Science</a></li>
													<li><a href="<?php echo BASEURL;?>commerce-department">Commerce</a></li>
													<li><a href="<?php echo BASEURL;?>tenth-standard-department">10<sup style="text-transform:lowercase">th</sup> Standard</a></li>
													<li><a href="<?php echo BASEURL;?>engineering-department">Engineering & Diploma</a></li>
												</ul>
											</li>
											<li <?php if($tab == "media") echo 'class=active';?>><a href="javascript:void(0);">Media <i class="fa fa-angle-down" aria-hidden="true"></i></a>
												<ul>
													<li><a href="<?php echo BASEURL;?>news">News</a></li>
													<li><a href="<?php echo BASEURL;?>events">Events</a></li>
													<li><a href="<?php echo BASEURL;?>gallery">Gallery</a></li>
												</ul>
											</li>
											<li <?php if($tab == "blog") echo 'class=active';?>><a href="<?php echo BASEURL;?>blog">Blog</a></li> 
											<li <?php if($tab == "contact") echo 'class=active';?>><a href="<?php echo BASEURL;?>contact-us">Contact Us</a></li>
										</ul>
									</nav>
								</div>
							</div>                          
						</div> 
					</div>
				</div>
				<div class="mobile-menu-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="mobile-menu">
									<nav id="dropdown">
										<ul>
											<li><a href="<?php echo BASEURL;?>">Home</a></li>
											<li><a href="<?php echo BASEURL;?>about-us">About Us</a></li>
											<li><a href="javascript:void(0);">Courses</a>
												<ul>
													<li><a href="<?php echo BASEURL;?>tenth-standard">10<sup style="text-transform:lowercase">th</sup> Standard</a></li>										
													<li><a href="<?php echo BASEURL;?>puc-science">I-II PUC Science</a></li>										
													<li><a href="<?php echo BASEURL;?>puc-commerce">I-II PUC Commerce</a></li>										
													<li><a href="<?php echo BASEURL;?>cet">NEET/ JEE/ K-CET/ COMED-K</a></li>										
													<li><a href="<?php echo BASEURL;?>bcom-bbm">B.Com & BBM</a></li>										
													<li><a href="<?php echo BASEURL;?>diploma">Diploma</a></li>										
													<li><a href="<?php echo BASEURL;?>engineering">Engineering</a></li>										
													<li><a href="<?php echo BASEURL;?>ca-cpt">CA-CPT</a></li>										
													<li><a href="<?php echo BASEURL;?>cs-cma">CS-CMA</a></li>										
												</ul>   
											</li>
											<li><a href="javascript:void(0);">Departments</a>
												<ul>
													<li><a href="<?php echo BASEURL;?>science-department">Science</a></li>
													<li><a href="<?php echo BASEURL;?>commerce-department">Commerce</a></li>
													<li><a href="<?php echo BASEURL;?>tenth-standard-department">10<sup style="text-transform:lowercase">th</sup> Standard</a></li>
													<li><a href="<?php echo BASEURL;?>engineering-department">Engineering & Diploma</a></li>
												</ul>
											</li>
											<li><a href="javascript:void(0);">Media</a>
												<ul>
													<li><a href="<?php echo BASEURL;?>news">News</a></li>
													<li><a href="<?php echo BASEURL;?>events">Events</a></li>
													<li><a href="<?php echo BASEURL;?>gallery">Gallery</a></li>
												</ul>
											</li>
											<li><a href="<?php echo BASEURL;?>blog">Blog</a></li> 
											<li><a href="<?php echo BASEURL;?>contact-us">Contact US</a></li>
										</ul>
									</nav>
								</div>           
							</div>
						</div>
					</div>
				</div>  
			</header>
