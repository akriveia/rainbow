<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | CA - CPT</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>CA - CPT</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>CA - CPT</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
				<div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">CA - CPT</h2>
									<p>In today’s competitive environment of Job market, just having the B.com & BBM degrees doesn’t secure you a job. It has almost become a necessary to obtain certificate in one of the professional courses in commerce stream.</p>								
									<p>To help such aspirants, Rainbow has come up with an excellent coaching model for professional courses such as,</p>								
									<ul class="course-feature">                                             
										<li>Chartered Accountant (CA)</li>                                                   
										<li>Company Secretary (CS)</li>                                                   
										<li>Certified Management Accountant (CMA)</li>                                                   
									</ul>
									<p>Coaching for these professional courses offered by Rainbow is completely career oriented. We provide certificate and placement assistance. </p>								
									<p>Teaching staff includes senior accountants and highly qualified professors in accountancy. Their experience and expertise will help learners in many ways.</p>								
									<p>Study materials Include interview questions & answers, audio clips of mock interviews, important notes on various topics. </p>								
									<p>Check out the course details in below table</p>								
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>CA - CPT</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Entrance Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>6 months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>B.com</td>
															</tr>
															<tr>
																<th>Subject / Syllabus</th>
																<td>CPT, IPC, Final</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer">
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. Hari Prasad</h4>
																	<p><em>M.Com., CA-Final</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Accountancy (CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. Pradeep</h4>
																	<p><em>M.Com. , MBA</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Business Studies</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/female-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Ms. Saraswathi</h4>
																	<p><em>MA. B.Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Economics(CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>															
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">
															<div class="media-body">
																<h3>Jeevan S</h3>
																<p>Got lots of positive reviews about our institute.. nice to hear but academics results proved one of the best teaching institutions ... happy to be a part of this institution.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">
															<div class="media-body">
																<h3>Aakash Sridhar</h3>
																<p>Very patient to hear out the students problems and difficulties. They work for the student success. The biggest plus point is they keep repeating the topics again an again, so if you miss any class, you will not be affected.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>                                                        
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include('course-carousel.php');?>					
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>