<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="related-courses-title-area">
								<h2 class="title-default-left title-bar-high">Our Popular Courses</h2>
							</div>
							<div id="shadow-carousel" class="related-courses-carousel">    
								<div class="rc-carousel"
									data-loop="true"
									data-items="4"
									data-margin="15"
									data-autoplay="true"
									data-autoplay-timeout="3000"
									data-smart-speed="3000"
									data-dots="false"
									data-nav="true"
									data-nav-speed="false"
									data-r-x-small="1"
									data-r-x-small-nav="true"
									data-r-x-small-dots="false"
									data-r-x-medium="2"
									data-r-x-medium-nav="true"
									data-r-x-medium-dots="false"
									data-r-small="1"
									data-r-small-nav="true"
									data-r-small-dots="false"
									data-r-medium="3"
									data-r-medium-nav="true"
									data-r-medium-dots="false"
									data-r-large="4"
									data-r-large-nav="true"
									data-r-large-dots="false">                                     
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-1.jpg" alt="10th Standard">
												<a href="<?php echo BASEURL;?>tenth-standard"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>tenth-standard">10<sup>th</sup> Standard</a></h3>
												<p class="item-content">10<sup>th</sup> Standard is the career foundation for students and Rainbow is committed to make strong career foundation.</p>
												<a href="<?php echo BASEURL;?>tenth-standard" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-2.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>puc-science"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>puc-science">I-II PUC Science</a></h3>
												<p class="item-content">Science stream is the stepping stone for engineering and medical aspirants and we provide strong foundation.</p>
												<a href="<?php echo BASEURL;?>puc-science" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-3.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>puc-commerce"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>puc-commerce">I-II PUC Commerce</a></h3>
												<p class="item-content">Accounting and finance is the backbone of commerce stream and we create an operational environment for this.</p>
												<a href="<?php echo BASEURL;?>puc-commerce" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-4.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>cet"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>cet">NEET/ JEE/ K-CET/ COMED-K</a></h3>
												<p class="item-content">Rainbow helps students to start preparing for Competitive Entrance Test along with their board exam preparations</p>
												<a href="<?php echo BASEURL;?>cet" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-5.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>bcom-bbm"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>bcom-bbm">B.Com & BBM</a></h3>
												<p class="item-content">Rainbow help students to understand the importance of accounting for monitoring and guiding business operations.</p>
												<a href="<?php echo BASEURL;?>bcom-bbm" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-6.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>diploma"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>diploma">Diploma</a></h3>
												<p class="item-content">Rainbow coaching and study materials helps diploma students to easily comprehend complex engineering topics.</p>
												<a href="<?php echo BASEURL;?>diploma" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-7.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>engineering"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>engineering">Engineering</a></h3>
												<p class="item-content">We provide coaching for Electronics, Mechanical ,Computer science branches and mathematics to all branches.</p>
												<a href="<?php echo BASEURL;?>engineering" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-8.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>ca-cpt"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>ca-cpt">CA-CPT</a></h3>
												<p class="item-content">Rainbow has an excellent career oriented coaching for CA-CPT along with certificate and placement assistance</p>
												<a href="<?php echo BASEURL;?>ca-cpt" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
									<div class="courses-box1 thumbnail">
										<div class="single-item-wrapper">
											<div class="courses-img-wrapper hvr-bounce-to-right">
												<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-9.jpg" alt="courses">
												<a href="<?php echo BASEURL;?>cs-cma"><i class="fa fa-link" aria-hidden="true"></i></a>
											</div>
											<div class="courses-content-wrapper">
												<h3 class="item-title"><a href="<?php echo BASEURL;?>cs-cma">CS-CMA</a></h3>
												<p class="item-content">Rainbow has an excellent career oriented coaching for CA-CPT along with certificate and placement assistance</p>
												<a href="<?php echo BASEURL;?>cs-cma" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
											</div>
										</div>
									</div>
								</div> 
							</div>
						</div>
					</div>
					