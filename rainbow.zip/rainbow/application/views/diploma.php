<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Diploma</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>Diploma</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Diploma</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
				<div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">Diploma</h2>
									<p>We conduct coaching classes for diploma students. Diploma has engineering subjects and involves highly technical learning which could be little harsh on students who have just passed out of high school.</p>
									<p>Here at Rainbow, we make things easier for these students. Coaching and study materials are designed in such a way that students can easily comprehend complex topics and concepts. </p>
									<p>Study materials include subject notes, audio lectures, test papers etc. Topic revisions and Mock tests are conducted regularly to make sure students are well prepared for their semester exams. </p>
									<p>We have a different coaching model for civil/Mechanical and other branches in Diploma. Check out the below table for details.</p>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>All Branches</th>														
															<th>Civil & Mechanical</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Test</td>
																<td>Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>N Months</td>
																<td>N Months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>10<sup>th</sup> / SSLC passed students</td>
																<td>10<sup>th</sup> / SSLC passed students</td>
															</tr>
															<tr>
																<th>Subjects / Syllabus</th>
																<td>Maths-1, Maths-2, Basics of Electronics & Electrical Concepts</td>
																<td>Engineering Drawing/Graphics, Fluid Mechanics & Machinery, Theory of Machines, Strength Materials, Thermal I&II, Design of Machines</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer">
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Dr. Harish</h4>
																	<p>Assistant Professor</p>
																	<p><em>M.Tech., Ph.D</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Electronics</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Dr. Srinivas R</h4>
																	<p>Associate Professor</p>
																	<p><em>M.Tech., Ph.D</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>13 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Mechanical</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/female-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Ms. Sarika</h4>
																	<p><em>M.Tech</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Computer Science </p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>															
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">												
															<div class="media-body">
																<h3>Chaitra</h3>
																<p>Best place to learn...Well occupied space... Good qualified teachers...High rate of score expected from all students... Importance given for all the students...well trained staff and community...Best coaching center</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">												
															<div class="media-body">
																<h3>Aakash Sridhar</h3>
																<p>Very patient to hear out the students problems and difficulties. They work for the student success. The biggest plus point is they keep repeating the topics again an again, so if you miss any class, you will not be affected.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>