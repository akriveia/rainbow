<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | I - II PUC Commerce</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>I - II PUC Commerce</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>I - II PUC Commerce</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
				<div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">I - II PUC Commerce</h2>
									<p>Rainbow institute offers coaching in commerce stream for pre-university (both I & II PUC) students. The number of students opting for commerce after 10th has increased exponentially in last few years.</p>
									<p>EABC, SEBA, MEBA, MSBA are the subjects taught for I & II PUC commerce students.</p>
									<p>Accounting and finance education is backbone of commerce stream and we provide adequate basic education about both. For I & II PUC commerce students we create operational environment in the field of accounting and financing. </p>									
									<p>Rainbow employs highly qualified and skilled people in the field of commerce to train our students.</p>
									<p>We have regularly visiting guest lectures from well-known education organizations who are already established names in commerce education.</p>
									<p>Regular Mock tests and practice tests will be conducted in order to make sure students are aware of the progress they are making.</p>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>I & II PUC Commerce</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Entrance Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>8 months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>10<sup>th</sup> and 11<sup>th</sup> passed students</td>
															</tr>
															<tr>
																<th>Syllabus Covered</th>
																<td>EABC, SEBA, MEBA, MSBA</td>
															</tr>
															<tr>
																<th>Class Commencement</th>
																<td>April 1st week</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer">
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. Hari Prasad</h4>
																	<p><em>M.Com., CA-Final</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Accountancy (CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. Pradeep</h4>
																	<p><em>M.Com. , MBA</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Business Studies</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/female-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Ms. Saraswathi</h4>
																	<p><em>MA. B.Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Economics(CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>															
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">
															<div class="media-body">
																<h3>Jeevan S</h3>
																<p>Got lots of positive reviews about our institute.. nice to hear but academics results proved one of the best teaching institutions ... happy to be a part of this institution.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">
															<div class="media-body">
																<h3>Aakash Sridhar</h3>
																<p>Very patient to hear out the students problems and difficulties. They work for the student success. The biggest plus point is they keep repeating the topics again an again, so if you miss any class, you will not be affected.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>                                                        
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>