<div class="sidebar">
									<div class="sidebar-box">
										<div class="sidebar-box-inner">
											<h3 class="sidebar-title">Enroll Now !!!</h3>
											<div class="sidebar-question-form"> 
												<form action="<?php echo BASEURL;?>save-enquiry" method="post" id="side-enquiry-form">
													<fieldset>
														<div class="form-group">
															<span><i class="fa fa-user"></i></span>
															<input type="text" placeholder="Name*" class="form-control" name="name">
														</div>
														<div class="form-group">
															<span><i class="fa fa-envelope"></i></span>
															<input type="email" placeholder="Email*" class="form-control" name="email">
														</div>
														<div class="form-group">
															<span><i class="fa fa-phone"></i></span>
															<input type="email" placeholder="Mobile*" class="form-control" name="mobile">
														</div>
														<div class="form-group">
															<span style="height:100%;padding-top:10%;"><i class="fa fa-comment"></i></span>
															<textarea placeholder="Message" class="textarea form-control" name="message" rows="3" cols="20" style="resize:none"></textarea>
														</div>
														<div class="col-md-12 col-xs-12 p0">
															<label id="form-error"></label>
															<div class="button-mask"></div>
															<input type="submit" id="enquiry-now" value="Submit" class="default-full-width-btn"/>
														</div>
													</fieldset>
												</form>
											</div>
										</div>
									</div>
								</div>
								