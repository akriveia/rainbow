<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | About Us</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "about";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/crum-bg2.jpg');background-repeat:repeat">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>About Us</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>About Us</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="about-page2-area">
                <div class="container">
					<h2 class="abt-title">About Our Institution</h2>					
				</div>
                <div class="container">
                    <div class="row about-page2-inner">
                        <div class="col-lg-7 col-md-6 col-sm-6 col-xs-12 text-justify wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.3s">
                            <p>Rainbow institution provides a variety of learning environments and learning spaces. This institute was established in 2012 by a bunch of scholars with an innovative practice. Mr Hari Prasad and his team came up with the idea of starting an institute that not only offers quality education but also upholds the true spirit of teaching and learning process. Rainbow has been implemented with honest dedication and continuous improvement. Thanks to the relentless efforts of our faculty to make the process of learning truly knowledge oriented, now we are one of the most favorite pick for the students and aspirants in the South Region of Bengaluru.</p>
                            <h4 class="sidebar-title"><b>How are we different ?</b></h4>
							<p>Our ability to bring the change in the way how students perceive the learning process is what makes us stand out from our peers in the education field. According to recent studies conducted in education sector, Things that comes to student's mind when they hear education & learning are exams, marks & grades. Rainbow is promoting knowledge based true learning system rather than making the education just about exams, marks & ranks.</p>
                        </div>
                        <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12  wow fadeInRight" data-wow-duration="2s" data-wow-delay="1s">                            
                            <img src="<?php echo BASEURL;?>assets/images/abt-banner.png" class="img-responsive p10"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="why-choose-area" id="mission-vision">                                
                <div class="container">
                     <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.1s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="javascript:void(0);"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Vision</h3>
                                <p>We will be a world leader in preparing professionals who provide leadership and exemplary educational and related services to improve the lives of individuals in a changing and complex global society.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.3s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="javascript:void(0);"><i class="fa fa-bell-o" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Mission</h3>
                                <p>Nothing extravagant here, we are on a simple yet very practical mission. To help students achieve their academic goals and make them realize the importance of constant learning.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="javascript:void(0);"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Values</h3>
                                <p>Institute is committed to build student's character along with career. Value based education promoted here, creates positive experience for students & empowers the choices they make in future.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="about-page2-area">
                <div class="container">
					<h2 class="abt-title">Founder's Message</h2>
				</div>
                <div class="container">
                    <div class="row about-page2-inner">
                        <div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 text-justify wow fadeIn" data-wow-duration="1s" data-wow-delay="0.3s">
                            <p><strong>Dear Parents & Students</strong></p>
                            <p><strong>Greetings!! </strong></p>
                            <p>We at Rainbow consider that "Education is not preparation for exam, it is to prepare for life itself". It is our duty to nurture the habit of constant learning & building career, Leadership in the students. For a responsible and well-educated society to uproot & Cherish, it is important to nurture the energy and talent our student possess. Our combined efforts would bring out best in their career and best in their lives as well.</p>
                            <p>We wish you a very productive experience at Rainbow</p>
						</div>
                        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center wow fadeIn" data-wow-duration="2s" data-wow-delay="0.5s">                            
                            <img src="<?php echo BASEURL;?>assets/images/founder.jpg" class="img-responsive img-thumbnail"/>
                        </div>
                    </div>
                </div>
            </div>
			<div class="about-page2-area whyus-bg">
                <div class="container">
					<div class="row">
						<div class="col-md-12 col-xs-12 col-sm-12">
							<h2 class="abt-title white-color">Why Choose Rainbow?</h2>
							<p class="text-justify white-color" style="position:relative">The institute is well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts which provides a suitable platform for students to prepare well for their board/annual exams or the other competitive exams. Rainbow’s staff and faculty members are committed and dedicated to students’ academic, cultural, social and overall progress. </p>
						</div>
					</div>
                </div>
			</div>
            <div class="about-page2-area" id="facilities">                                
                <div class="container">
					<div class="row">
						<div class="col-md-12 col-xs-12 col-sm-12 panel-group" id="faq-accordian">
							<div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 pl0 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.4s">
								<div class="faq-box-wrapper">
									<div class="faq-box-item panel panel-default">
										<div class="panel-heading active">
											<div class="panel-title faq-box-title">
												<h3>
													<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Administration</a>
												</h3>
											</div>
										</div>
										<div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse in">
											<div class="panel-body faq-box-body text-justify">
												<p>We have a separate administration section which acts as info-hub for providing administration related information and supervising administrative activities like general admin, documentations, back office operations etc. Admin department is always at the service of students and faculty members.</p>
											</div>
										</div>
									</div>
								</div>
								<div class="faq-box-wrapper">
									<div class="faq-box-item panel panel-default">
										<div class="panel-heading">
											<div class="panel-title faq-box-title">
												<h3>
													<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">About Faculty</a>
												</h3>
											</div>
										</div>
										<div aria-expanded="false" id="collapseFour" role="tabpanel" class="panel-collapse collapse">
											<div class="panel-body faq-box-body text-justify">
												<p>Faculty members are passionate and curious individuals who continue their own research while teaching at rainbow institution. They come from excellent teaching background bringing with a bag full of experience and diverse wealth of knowledge.</p>
												<p>Academic curriculum & courses are designed, taught and supervised by faculty members. Every student at Rainbow will have access to faculty which enables closer teacher-student relationship. Every teacher puts volunteer effort to connect to students to make the learning experience fulfilling.</p>
											</div>
										</div>
									</div>
								</div>
								<div class="faq-box-wrapper">
									<div class="faq-box-item panel panel-default">
										<div class="panel-heading">
											<div class="panel-title faq-box-title">
												<h3>
													<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Facilities Offered</a>
												</h3>
											</div>
										</div>
										<div aria-expanded="false" id="collapseTwo" role="tabpanel" class="panel-collapse collapse">
											<div class="panel-body faq-box-body text-justify">
												<p>Rainbow has an excellent infrastructure, situated in a calm and tranquil area. Classrooms are well equipped with necessary furniture and are spacious for 50 students. Faculty and students are provided with all the teaching aids such as LCD projectors, microphones, multimedia Computer, audio systems etc.</p>
												<p>Classroom training is made interactive through debates, quizzes, assignments, case studies and presentations by students.</p>
											</div>
										</div>
									</div>
								</div>
								<div class="faq-box-wrapper">
									<div class="faq-box-item panel panel-default">
										<div class="panel-heading">
											<div class="panel-title faq-box-title">
												<h3>
													<a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Instruction Methodologies</a>
												</h3>
											</div>
										</div>
										<div aria-expanded="false" id="collapseThree" role="tabpanel" class="panel-collapse collapse">
											<div class="panel-body faq-box-body text-justify">
												<p>Here in Rainbow, teaching staff adopts various instruction methodologies in order to create the fulfilling learning experience for students. Not only Faculty is given free hand to experiment, design and develop methodologies, but Students are also encouraged to come up with suggestions. Basically we involve all the stakeholders in the process. Here are few sample methodologies.</p>
												<div class="col-lg-12 col-md-12 col-sm-12 course-details-tab-area p0 mt10">
													<ul class="course-details-tab-btn">
														<li class="active"><a href="#Lecturette" data-toggle="tab" aria-expanded="false">Lecturette </a></li>
														<li><a href="#classroom" data-toggle="tab" aria-expanded="false">Classroom discussion </a></li>
														<li><a href="#material" data-toggle="tab" aria-expanded="false">Study Material </a></li>
														<li><a href="#quiz" data-toggle="tab" aria-expanded="false">Quiz </a></li>
													</ul>
													<div class="col-lg-12 col-md-12 col-sm-12 tab-content">
														<div class="tab-pane fade active in p10" id="Lecturette">
															<p>A structured oral presentation method in which students are allowed to present content in segments ranging from 5 to 20 minutes.</p>
														</div>
														<div class="tab-pane fade p10" id="classroom">
															<p>Teacher will assign few questions to students. This is basically question & answer session where learners will have to answer to questions asked by the teacher. Learners are asked to speak to person beside them for few minutes to discuss about the topic and answer a question. </p>
														</div>
														<div class="tab-pane fade p10" id="material">
															<p>A simple and easy study Guide that provide map for learners. This material includes Solved test papers, Q&A book, Solved puzzles, mock test papers, Audio Lectures etc.</p>
														</div>
														<div class="tab-pane fade p10" id="quiz">
															<p>Filling out a questionnaire to test the knowledge, especially as a competition between individuals or teams as a form of entertainment.</p>
														</div>
													</div>
												</div>
												<p>We always experiment with instruction methodologies and develop innovative processes of learning. </p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-5 col-sm-12 col-xs-12 wow fadeInRight" data-wow-duration="2s" data-wow-delay="0.5s">
								<h4 class="sidebar-title"><b>Rainbow Values</b></h4>
								<div class="skill-area">
									<div class="progress">
										<div class="lead">Learning</div>
										<div data-wow-delay="1.2s" data-wow-duration="1.5s" style="width: 100%; visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;" data-progress="100%" class="progress-bar wow fadeInLeft  animated"></div><span>100%</span>
									</div>
									<div class="progress">
										<div class="lead">Innovation</div>
										<div data-wow-delay="1.2s" data-wow-duration="1.5s" style="width: 90%; visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;" data-progress="90%" class="progress-bar wow fadeInLeft  animated"></div><span>90%</span> 
									</div>
									<div class="progress">
										<div class="lead">Relationship</div>
										<div data-wow-delay="1.2s" data-wow-duration="1.5s" style="width:95%; visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;" data-progress="95%" class="progress-bar wow fadeInLeft  animated"></div><span>95%</span> 
									</div>
									<div class="progress">
										<div class="lead">Career</div>
										<div data-wow-delay="1.2s" data-wow-duration="1.5s" style="width: 90%; visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;" data-progress="90%" class="progress-bar wow fadeInLeft  animated"></div><span>90%</span> 
									</div>
									<div class="progress">
										<div class="lead">Commitment</div>
										<div data-wow-delay="1.2s" data-wow-duration="1.5s" style="width: 100%; visibility: visible; animation-duration: 1.5s; animation-delay: 1.2s; animation-name: fadeInLeft;" data-progress="100%" class="progress-bar wow fadeInLeft  animated"></div><span>100%</span> 
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
            <div class="why-choose-area lecturers-area hidden" id="our-team">
                <div class="container">    
                    <h2 class="abt-title">Our Skilled Lecturers</h2> 
                </div>
                <div class="container">    
                    <div class="rc-carousel"
                        data-loop="true"
                        data-items="3"
                        data-margin="30"
                        data-autoplay="false"
                        data-autoplay-timeout="10000"
                        data-smart-speed="2000"
                        data-dots="false"
                        data-nav="true"
                        data-nav-speed="false"
                        data-r-x-small="1"
                        data-r-x-small-nav="true"
                        data-r-x-small-dots="false"
                        data-r-x-medium="2"
                        data-r-x-medium-nav="true"
                        data-r-x-medium-dots="false"
                        data-r-small="2"
                        data-r-small-nav="true"
                        data-r-small-dots="false"
                        data-r-medium="3"
                        data-r-medium-nav="true"
                        data-r-medium-dots="false"
                        data-r-large="3"
                        data-r-large-nav="true"
                        data-r-large-dots="false"> 
                        <div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/17.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. HARI PRASAD</h3>
									<span>M.Com., CA-Final</span>
									<p>10 Year's Experience </p>
									<p>Specialization: Accountancy (CPT/IPCC)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
                        <div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/16.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. PRASAD B K</h3>
									<span>M.Sc., M.Phil.</span>
									<p>12 Years’ Experience</p>
									<p>Specialization: Physics (NEET/IIT-JEE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
                        <div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/14.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. MOHAN B K</h3>
									<span>M.Sc., Ph.D</span>
									<p>15 Year's Experience</p>
									<p>Specialization: Biology (NEET)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. MANJUNATH S R</h3>
									<span>M.Sc., M.Ed</span>
									<p>20 Year's Experience</p>
									<p>Specialization: Chemistry (NEET/IIT-JEE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. LAKSHMAN V</h3>
									<span>M.Sc., B. Ed</span>
									<p>12 Years’ Experience</p>
									<p>Specialization: Mathematics (NEET/IIT-JEE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. PRADEEP</h3>
									<span>M.Com., MBA</span>
									<p>10 Years’ Experience</p>
									<p>Specialization : Business Studies</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Ms. SARASWATHI</h3>
									<span>MA. B.Ed</span>
									<p>12 Year's Experience</p>
									<p>Specialization: Economics(CPT/IPCC)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. MANU</h3>
									<span>M.Sc. B.Ed</span>
									<p>12 Years’ Experience</p>
									<p>Specialization: Mathematics (State/CBSE/ICSE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. Rajesh S</h3>
									<span>M.Sc. M.Ed</span>
									<p>20 Year's Experience</p>
									<p>Specialization: Chemistry & Biology (State/CBSE/ICSE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Mr. Nayana</h3>
									<span>M.Sc. B.Ed</span>
									<p>13 Years’ Experience</p>
									<p>Specialization: Physics (State/CBSE/ICSE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Ms. Saroja</h3>
									<span>M.A. B.Ed</span>
									<p>10 Years’ Experience</p>
									<p>Specialization: Social Science (State/CBSE/ICSE)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Dr. Harish</h3>
									<span>M.Tech., Ph.D</span>
									<p>10 Years’ Experience</p>
									<p>Specialization: Electronics (Assistant Professor)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Dr. Srinivas R</h3>
									<span>M.Tech., Ph.D</span>
									<p>13 Years’ Experience</p>
									<p>Specialization: Mechanical (Associate Professor)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
						<div class="single-item">
                            <div class="lecturers-item-wrapper">
								<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/15.jpg" alt="team"></a>
								<div class="lecturers-content-wrapper">
									<h3>Ms. Sarika</h3>
									<span>M.Tech</span>
									<p>10 Years’ Experience</p>
									<p>Specialization: Computer Science (Associate Professor)</p>
									<ul class="lecturers-social">
										<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
                        </div>
                    </div> 
                </div>  
            </div>
            <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>