<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="google-site-verification" content="zbfc4lOwcDSYfZ7TObBQgoc5Hj1VRLM9ooOAzn3uA8Q" />
		<link rel="alternate" hreflang="en" href="http://www.rainbowinstitutions.com" />
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo BASEURL;?>assets/images/favicon.png">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
		<meta name="description" content="Rainbow is a well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts.">
		<meta name="keywords" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram">
		<meta content="2nd floor, Venkateshwara complex,Devasandra main road,Near GEETHA clinic, K R Puram,Bengaluru - 560036, Karnataka, India, +9197315 08686">
		<meta name="ROBOTS" content="index,follow" />
		<link rel="canonical" href="http://rainbowinstitutions.com/" />
		<meta property="og:title" content="Rainbow Institutions||Rainbow Academy||Rainbow Tutorials" />
		<meta property="og:description" content="Rainbow is a well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts." />
		<meta property="og:site_name" content="Rainbow Institutions" />
		<meta property="og:type" content="website "/>
		<meta property="og:locale" content="en_US" />
		<meta property="og:url" content="http://rainbowinstitutions.com/" />
		<meta property="og:image" content="http://rainbowinstitutions.com/assets/images/logo.png" />
		<link rel="canonical" href="http://rainbowinstitutions.com/" />
		<meta name="msapplication-starturl" content="http://rainbowinstitutions.com/?utm_source=ie9&utm_medium=web&utm_campaign=pinned-ie9"/>
		<meta itemprop="name" content="Rainbow Institutions||Rainbow Academy||Rainbow Tutorials" />
		<meta itemprop="description" content="Rainbow is a well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts." />
		<meta itemprop="image" content="http://rainbowinstitutions.com/assets/images/logo.png" />
		<meta itemprop="publisher" content="Rainbow Institutions" />
		<meta itemprop="url" content="http://rainbowinstitutions.com/" />
		<meta itemprop="editor" content="Rainbow Institutions" />
		<meta itemprop="headline" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state" />
		<meta itemprop="inLanguage" content="English" />
		<meta itemprop="sourceOrganization" content="Rainbow Institutions" />
		<meta itemprop="keywords" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="robots" content="noodp" />
		<meta name="Designer" content="http://rainbowinstitutions.com/" />
		<meta name="Revisit-After" content="1" />
		<meta name="Rating" content="General" />
		<meta name="distribution" content="Global" />
		<meta name="audience" content="all" />
		<meta name="Author" content="Rainbow Institutions" />
		<meta name="Language" content="English" />
		<meta name="category" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="classification" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="expires" content="never" />
		<meta name="owner" content="Rainbow Institutions" />
		<meta name="page-topic" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="resource-type" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="subject" content="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="DC.title" content="Rainbow Institutions||Rainbow Academy||Rainbow Tutorials" />
		<meta name="dc.keywords" CONTENT="Best Coaching Center for PUC,CET,CA-CPT,BE,Diploma,SSLC,CBSE,ICSE,state, CET coaching in bangalore,CA coaching in whitefield,CA coaching in K.R Puram,CET coaching in whitefield,CET coaching in K.R Puram" />
		<meta name="dc.subject" CONTENT="Rainbow Institutions||Rainbow Academy||Rainbow Tutorials">
		<meta name="dc.description" CONTENT="Rainbow is a well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts." />
		<meta name="DC.Type" content="Best Coaching Center" >
		<meta name="city" content="Bangalore" />
		<meta name="state" content="Karnataka" />
		<meta name="geo.region" content="IN-KA" />
		<meta name="geo.region" content="IN-KA" />
		<meta name="geo.placename" content="Bengaluru" />
		<meta name="geo.position" content="13.006728;77.6987096" />
		<meta name="ICBM" content="13.006728, 77.6987096" />
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/normalize.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/main.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/bootstrap.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/animate.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/font-awesome.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/owl.carousel.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/owl.theme.default.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/meanmenu.min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/nivo-slider.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/preview.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/jquery.datetimepicker.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/magnific-popup.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/hover-min.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/style.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/custom.css" type="text/css">
		<link rel="stylesheet" href="<?php echo BASEURL;?>assets/css/select2.min.css" type="text/css">
