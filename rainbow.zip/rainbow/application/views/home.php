<!doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow Institutions</title>
		<?php include_once("head-styles.php");?>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<script>
		  (adsbygoogle = window.adsbygoogle || []).push({
			google_ad_client: "ca-pub-2357170267040680",
			enable_page_level_ads: true
		  });
		</script>
    </head>
	<body>
        <div id="wrapper">
			<?php
				$tab = "index";
				include_once("menu.php");
				if(!empty($this->session->userdata("POPUP")))
				{
					$popup = $this->session->userdata("POPUP");					
				}
				else{
					$popup ="";
				}
			?>
			<div class="container" <?php if($popup == "filled") echo "style='display:none'"?>>
				<div class="modal fade" id="myModal" role="dialog" style="background: rgba(0, 0, 0, 0.6);">
					<div class="modal-dialog">
						<div class="col-md-12 col-sm-12 col-xs-12 modal-content ride-book p0">
							<div class="col-md-4 col-sm-12 col-xs-12 p0 visible-lg visible-md">
								<img src="<?php echo BASEURL;?>assets/images/popup-banner.jpg" class="img-responsive">
							</div>
							<div class="col-md-8 col-sm-12 col-xs-12 p0">
								<div class="col-md-12 col-sm-12 col-xs-12 modal-header" style="border:0">
									<button type="button" class="enquire-close close" data-dismiss="modal"><i class="fa fa-times-circle"></i></button>
									<h2 class="title-default-center mb10">Admissions Open For 2018-19</h2>
									<p class="text-center" style="color:#F00">Hurry up Limited seats only !!!</p>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 modal-body p0">
									<form method="post" action="<?php echo BASEURL;?>save-enquiry" id="enquiry-form">
										<div class="col-md-6 col-sm-12 col-xs-12 form-group">
											<input class="form-control" type="text" placeholder="Name" name="name"/>
										</div>
										<div class="col-md-6 col-sm-12 col-xs-12 form-group"> 
											<input class="form-control" type="text" placeholder="Contact" name="mobile"/>
										</div>
										<div class="col-md-6 col-sm-12 col-xs-12 form-group"> 
											<select name="course" id="choose-course" class="form-control" data-placeholder="Choose Course" data-allow-clear="true">
												<option value="">Choose Course</option>
												<option value="I PUC SCIENCE">I PUC SCIENCE</option>
												<option value="II PUC SCIENCE">II PUC SCIENCE</option>
												<option value="I PUC COMMERCE">I PUC COMMERCE</option>
												<option value="II PUC COMMERCE">II PUC COMMERCE</option>
												<option value="10th CBSE">10th CBSE</option>
												<option value="10th ICSE">10th ICSE</option>
												<option value="10th State">10th State</option>
												<option value="CET">NEET/ JEE/ K-CET/ COMED-K</option>
												<option value="B.Com">B.Com</option>
												<option value="BBM">BBM</option>
												<option value="Diploma">Diploma</option>
												<option value="Engineering">Engineering</option>
												<option value="CA-CPT">CA-CPT</option>
												<option value="CS-CMA">CS-CMA</option>
											</select>
										</div>
										<div class="col-md-6 col-sm-12 col-xs-12 form-group">
											<div class="custom-select">
												<select name="branch" id="choose-branch" class="form-control" data-placeholder="Choose Branch" data-allow-clear="true">
													<option value="">Choose Branch</option>
													<option value="Whitefield">Whitefield</option>
													<option value="KR Puram">K R Puram</option>
												</select>
											</div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12" style="height:30px">
											<label id="form-error"></label>
										</div>
										<div class="col-md-6 col-md-offset-4 col-sm-12 col-xs-12 form-group mb10">
											<div class="button-mask"></div>
											<input type="submit" id="register-now" class="view-all-accent-btn" value="REGISTER NOW"/>
										</div>
									</form>
								</div>
							</div>				
						</div>
					</div>
				</div>
			</div>
            <div class="slider1-area overlay-default">
                <div class="bend niceties preview-1">
                    <div id="ensign-nivoslider-3" class="slides">   
                        <img src="<?php echo BASEURL;?>assets/images/slider-1.jpg" alt="slider" title="#slider-direction-1"/>
                        <img src="<?php echo BASEURL;?>assets/images/slider-2.jpg" alt="slider" title="#slider-direction-2"/>
                        <img src="<?php echo BASEURL;?>assets/images/slider-3.jpg" alt="slider" title="#slider-direction-3"/>
                    </div>
                    <div id="slider-direction-1" class="t-cn slider-direction">
                        <div class="slider-content s-tb slide-1">
                            <div class="title-container s-tb-c">
                                <h1 class="title1">Excellent Coaching by Experienced Faculty.</h1>
                                <p>Excellent team of teaching faculty with more than 10 years of experience in teaching.</br>
								We have Micro level academic Plan to complete syllabus in time.</p>
                                <div class="slider-btn-area">
                                    <a href="<?php echo BASEURL;?>about-us" class="default-big-btn">About Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="slider-direction-2" class="t-cn slider-direction">
                        <div class="slider-content s-tb slide-2">
                             <div class="title-container s-tb-c">
                                <h1 class="title1">Best Education With Best Infrastructure</h1>
                                <p>We provide the best encouragement for potential learners and intensive coaching for slow learners.</br> 
								Personal assistance for individual student queries.</p>
                                <div class="slider-btn-area">
                                    <a href="<?php echo BASEURL;?>courses" class="default-big-btn">View Courses</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="slider-direction-3" class="t-cn slider-direction">
                        <div class="slider-content s-tb slide-3">
                             <div class="title-container s-tb-c">
                                <h1 class="title1">Achieve Your Dreams with Rainbow</h1>
                                <p>We perform counselling of students to bring out their best performance.</br>
								We conduct Periodic unit test & appraisal of results to parents.</p>
                                <div class="slider-btn-area">
                                    <a href="<?php echo BASEURL;?>contact-us" class="default-big-btn">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
			<div class="service1-area hidden-xs">
                <div class="service1-inner-area">
                    <div class="container">
                         <div class="row service1-wrapper">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 service-box1">
                                <div class="service-box-content">
                                    <h3><a href="<?php echo BASEURL;?>about-us">Best Infrastructure</a></h3>
                                    <p>Spacious and Ventilated Classrooms with Comfortable Seating.</p>
                                </div>
                                <div class="service-box-icon">
                                    <i class="fa fa-university" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 service-box1">
                                <div class="service-box-content">
                                    <h3><a href="<?php echo BASEURL;?>about-us">Experienced Faculty</a></h3>
                                    <p>Excellent Study Materials Prepared by Subject Experts.</p>
                                </div>
                                <div class="service-box-icon">
                                    <i class="fa fa-users" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 service-box1">
                                <div class="service-box-content">
                                    <h3><a href="<?php echo BASEURL;?>about-us">Excellent Coaching</a></h3>
                                    <p>A Well-Equipped Library for all Students.</p>
                                </div>
                                <div class="service-box-icon">
                                    <i class="fa fa-book" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about2-area">                                
                <div class="container">
                    <h2 class="wow fadeIn about-title">Welcome To Rainbow</h2>
                </div>
                <div class="container">
					<div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 wow fadeInLeft text-justify" data-wow-delay="0.3s">
							<p>Rainbow institution provides a variety of learning environments and learning spaces. This institute was established in 2012 by a bunch of scholars with an innovative practice. Mr Hari Prasad and his team came up with the idea of starting an institute that not only offers quality education but also upholds the true spirit of teaching and learning process. </p>
							<p>Rainbow has been implemented with honest dedication and continuous improvement. Thanks to the relentless efforts of our faculty to make the process of learning truly knowledge oriented, now we are one of the most favorite pick for the students and aspirants in the South Region of Bengaluru.</p>
							<p>Faculty members are passionate and curious individuals who continue their own research while teaching at rainbow institution. They come from excellent teaching background bringing with a bag full of experience and diverse wealth of knowledge.</p>
							<p>Rainbow has an excellent infrastructure, situated in a calm and tranquil area. Classrooms are well equipped with necessary furniture and are spacious for 50 students. Faculty and students are provided with all the teaching aids such as LCD projectors, microphones, multimedia Computer, audio systems etc.</p>
						</div>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInRight" data-wow-delay="0.9s">
							<img src="<?php echo BASEURL;?>assets/images/about-2.png" class="img-responsive" />
						</div>
                    </div>
					<div class="row">
						<div class="col-md-12 news-btn-holder wow fadeInLeft" data-wow-delay="0.3s">
							<a href="<?php echo BASEURL;?>about-us" class="view-all-accent-btn mt20">About Us</a>
						</div>
                    </div>
                </div>
            </div>
			<div class="why-choose-area">                                
                <div class="container">
					<div class="row">
						<h2 class="about-title">Why Choose Rainbow?</h2>
						<p class="sub-title-full-width">The institute is well recognized for its teaching quality and delivers best outcomes every year. Our method of teaching is wired with a strong foundation of knowledge and concepts which provides a suitable platform for students to prepare well for their board/annual exams or the other competitive exams. Rainbow’s staff and faculty members are committed and dedicated to students’ academic, cultural, social and overall progress. </p>
					</div>
                </div>
                <div class="container">
                     <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInDown" data-wow-duration="2s" data-wow-delay="0.1s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="<?php echo BASEURL;?>about-us"><i class="fa fa-book" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Lecturette </h3>
                                <p>A structured oral presentation method in which students are allowed to present content in segments ranging from 5 to 20 minutes.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInDown" data-wow-duration="2s" data-wow-delay="0.3s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="<?php echo BASEURL;?>about-us"><i class="fa fa-users" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Classroom discussion</h3>
                                <p>Teacher will assign few questions to students where learners will have to answer to questions asked by the teacher.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInDown" data-wow-duration="2s" data-wow-delay="0.5s">
                            <div class="service-box3">
                                <div class="service-box-icon">
                                    <a href="<?php echo BASEURL;?>about-us"><i class="fa fa-question" aria-hidden="true"></i></a>
                                </div>                      
                                <h3>Quiz</h3>
                                <p>Filling out a questionnaire to test the knowledge, especially as a competition between individuals or teams as a form of entertainment.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="featured-area bg-common-style">
                <div class="container">    
                    <h2 class="video-title">Popular Courses</h2> 
                </div>
                <div class="container">    
					<div class="row featured-wrapper">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s">
							<div class="featured-box">
								<div class="featured-img-holder hvr-bounce-to-right">
									<img src="<?php echo BASEURL;?>assets/images/course-1.jpg" class="img-responsive" alt="featured">
									<a href="<?php echo BASEURL;?>tenth-standard" class="default-big-btn">Enroll</a>
								</div>
								<div class="featured-content-holder text-center">
									 <h3><a href="<?php echo BASEURL;?>tenth-standard">10<sup>th</sup> Standard</a></h3>
									<p>10<sup>th</sup> Standard is where every student starts thinking about his/her career. This can be considered as the career foundation for students. </p>
								</div>
                            </div>
                        </div> 
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.2s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-2.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>puc-science" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>puc-science">I-II PUC Science</a></h3>
                                    <p>Science stream is the stepping stone for engineering and medical aspirants. We provide strong foundation for achieving academic goals. </p>
                                </div>  
                            </div>
                        </div> 
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-3.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>puc-commerce" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>puc-commerce">I-II PUC Commerce</a></h3>
                                    <p>Accounting and finance is the backbone of commerce stream. We create operational environment for accounting and financing. </p>
                                </div>  
                            </div>
						</div>
					</div>
					<div class="row featured-wrapper">
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.4s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-4.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>cet" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>cet">NEET/ JEE/ K-CET/ COMED-K</a></h3>
                                    <p>Rainbow provides an opportunity for students to start preparing for Competitive entrance test along with their board exam preparations. </p>
                                </div>  
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-5.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>bcom-bbm" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>bcom-bbm">B.Com & BBM</a></h3>
                                    <p>Rainbow help students to understand the importance of accounting which is essential for monitoring and guiding business operations.</p>
                                </div>  
                            </div>
						</div>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.6s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-6.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>diploma" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>diploma">Diploma</a></h3>
                                    <p>Rainbow coaching and study materials help diploma students to easily comprehend complex engineering topics and technical concepts.</p>
                                </div>  
                            </div> 
                        </div>
					</div>
					<div class="row featured-wrapper">
						<div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.7s">
                             <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-7.jpg" class="img-responsive" alt="featured">
									<a href="<?php echo BASEURL;?>engineering" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>engineering">Engineering</a></h3>
                                    <p>We provide coaching for Electronics, Mechanical and Computer science branches. Also, we teach mathematics to any engineering branch.</p>
                                </div>  
                            </div>
						</div>
						<div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-8.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>ca-cpt" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>ca-cpt">CA-CPT</a></h3>
                                    <p>Rainbow has an excellent coaching model for CA-CPT. Coaching is completely career oriented along with certificate and placement assistance</p>
                                </div>  
                            </div>
                        </div>
						<div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.9s">
                            <div class="featured-box">
                                <div class="featured-img-holder hvr-bounce-to-right">
                                    <img src="<?php echo BASEURL;?>assets/images/course-9.jpg" class="img-responsive" alt="featured">
                                   <a href="<?php echo BASEURL;?>cs-cma" class="default-big-btn">Enroll</a>
                                </div>  
                                <div class="featured-content-holder text-center">
                                    <h3><a href="<?php echo BASEURL;?>cs-cma">CS-CMA</a></h3>
                                    <p>Rainbow has an excellent coaching model for CA-CPT. Coaching is completely career oriented along with certificate and placement assistance</p>
                                </div>  
                            </div>
                        </div> 
                    </div> 
                    <div class="view-all-btn-area">
                        <a href="<?php echo BASEURL;?>courses" class="ghost-btn-big">View All Courses</a>
                    </div> 
                </div>  
            </div>            
            <div class="news-event-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 news-inner-area">
                            <h2 class="title-default-left">Latest News</h2>
                            <ul class="news-wrapper">
                                <li>
                                    <div class="news-img-holder">
                                        <a href="javascript:void(0);"><img src="<?php echo BASEURL;?>assets/images/news.png" class="img-responsive" alt="news"></a>
                                    </div>
                                    <div class="news-content-holder">
                                        <h3><a href="javascript:void(0);">Admissions Open for II PUC 2017-18</a></h3>
                                        <div class="post-date">Aug 25, 2017</div>
                                        <p>Admissions open for Intergrated , Regular and Vacation Batch. Register Now</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="news-img-holder">
                                        <a href="javascript:void(0);"><img src="<?php echo BASEURL;?>assets/images/news.png" class="img-responsive" alt="news"></a>
                                    </div>
                                    <div class="news-content-holder">
                                        <h3><a href="javascript:void(0);">K-CET 2017 Crash Course</a></h3>
                                        <div class="post-date">July 05, 2017</div>
                                        <p>Admissions open for K-CET 2017 Crash Course, Hurry up Limited seats available</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="news-img-holder">
                                        <a href="javascript:void(0);"><img src="<?php echo BASEURL;?>assets/images/news.png" class="img-responsive" alt="news"></a>
                                    </div>
                                    <div class="news-content-holder">
                                        <h3><a href="javascript:void(0);">Admissions Open For 10<sup>th</sup> Standard</a></h3>
                                        <div class="post-date">June 15, 2017</div>
                                        <p>Admissions open for 10<sup>th</sup> Standard, Hurry up Limited seats available</p>
                                    </div>
                                </li>
                            </ul>
                            <div class="news-btn-holder">
                                <a href="#" class="view-all-accent-btn">View All</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 event-inner-area text-justify">
                            <h2 class="title-default-left">Upcoming Events</h2>
                            <ul class="event-wrapper">
                                <li>
                                    <div class="event-calender-wrapper">
                                        <div class="event-calender-holder">
                                            <h3>26</h3>
                                            <p>Sep</p>
                                            <span>2017</span>
                                        </div>
                                    </div>
                                    <div class="event-content-holder">
                                        <h3><a href="javascript:void(0);">FREE Classes for II PUC Accountancy by Experts</a></h3>
                                        <p>We are happy to announce that we are conducting FREE classes for II PUC Accountancy by Experts. </p>
										<p>Hurry up limited seats only !!!</p>
                                        <ul>
                                            <li>7.15 AM to 8.15 AM</li>
                                            <li>ADVITYA PU and Degree college</li>
                                        </ul>
                                    </div>
                                </li>
                                <li>
                                    <div class="event-calender-wrapper">
                                        <div class="event-calender-holder">
                                            <h3>10</h3>
                                            <p>Sep</p>
                                            <span>2017</span>
                                        </div>
                                    </div>
                                    <div class="event-content-holder">
                                        <h3><a href="javascript:void(0);">Free Formula Book For PU Students.</a></h3>
                                        <p>We are glad to inform you that we are issuing FREE FORMULA BOOK for PU students. Kindly collect your book at our Office. Please inform your Friends & Relatives</p>
                                        <ul>
                                            <li>03:00 PM - 05:00 PM</li>
                                            <li>Rainbow Tutorial, K R Puram</li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                            <div class="event-btn-holder">
                                <a href="#" class="view-all-primary-btn">View All</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="students-say-area">
                <h2 class="title-default-center">What Our Students Say</h2> 
                <div class="container">    
                    <div class="rc-carousel"
                        data-loop="true"
                        data-items="1"
                        data-margin="30"
                        data-autoplay="true"
                        data-autoplay-timeout="10000"
                        data-smart-speed="2000"
                        data-dots="true"
                        data-nav="false"
                        data-nav-speed="false"
                        data-r-x-small="1"
                        data-r-x-small-nav="false"
                        data-r-x-small-dots="true"
                        data-r-x-medium="1"
                        data-r-x-medium-nav="false"
                        data-r-x-medium-dots="true"
                        data-r-small="1"
                        data-r-small-nav="false"
                        data-r-small-dots="true"
                        data-r-medium="1"
                        data-r-medium-nav="false"
                        data-r-medium-dots="true"
                        data-r-large="1"
                        data-r-large-nav="false"
                        data-r-large-dots="true"> 
                        <div class="single-item">
                            <div class="single-item-wrapper">
                                <div class="tlp-tm-content-wrapper">
                                    <h3 class="item-title">Bhuvan</h3>
                                    <span class="item-designation">II PUC Science</span>
                                    <ul class="rating-wrapper">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                    <div class="item-content">For sure Rainbow is one of the best institutes I have studied in. Teacher-student bonding is great which really makes learning easier.</div>
                                </div>
                            </div>
                        </div>
                        <div class="single-item">
                            <div class="single-item-wrapper">
                                <div class="tlp-tm-content-wrapper">
                                    <h3 class="item-title">Chethan</h3>
                                    <span class="item-designation">B.E, 3<sup>rd</sup> Sem</span>
                                    <ul class="rating-wrapper">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                    <div class="item-content">Mathematics is not the toughest subject for me anymore. The way teachers teach maths is just mind blowing & it can’t be explained in words, one has to experience it.</div>
                                </div>
                            </div>
                        </div>
                        <div class="single-item">
                            <div class="single-item-wrapper">
                                <div class="tlp-tm-content-wrapper">
                                    <h3 class="item-title">Akshatha</h3>
                                    <span class="item-designation">CA, Alumna</span>
                                    <ul class="rating-wrapper">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                    <div class="item-content">Rainbow institute helped me become a professional Chartered accountant. Thanks to their career oriented training methodology, now i’m working with a reputed CA firm. </div>
                                </div>
                            </div>
                        </div>
						<div class="single-item">
                            <div class="single-item-wrapper">
                                <div class="tlp-tm-content-wrapper">
                                    <h3 class="item-title">Shamitha</h3>
                                    <span class="item-designation">II PUC Science</span>
                                    <ul class="rating-wrapper">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                    <div class="item-content">Coaching is nice. study materials are excellent and easy to understand. Best coaching center for 2nd PUC competitive and regular courses.</div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>  
            </div>
			<div class="counter-area bg-primary-deep">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".10s">
                            <h2 class="about-counter title-bar-counter" data-num="3">3</h2>
                            <p>BRANCHES IN BANGALORE</p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".10s">
                            <h2 class="about-counter title-bar-counter" data-num="9">9</h2>
                            <p>ACADEMIC COURSES</p>
                        </div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".10s">
                            <h2 class="about-counter title-bar-counter" data-num="30">30</h2>
                            <p>PROFESSIONAL TEACHER</p>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".10s">
                            <h2 class="about-counter title-bar-counter" data-num="600">600</h2>
                            <p>REGISTERED STUDENTS EVERY YEAR</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="brand-area">
				<div class="container">
                    <h2 class="wow fadeIn title-default-center">Our Partners</h2>
                </div>
                <div class="container">
                    <div class="rc-carousel"
                        data-loop="true"
                        data-items="6"
                        data-margin="50"
                        data-autoplay="true"
                        data-autoplay-timeout="5000"
                        data-smart-speed="2000"
                        data-dots="false"
                        data-nav="true"
                        data-nav-speed="false"
                        data-r-x-small="2"
                        data-r-x-small-nav="true"
                        data-r-x-small-dots="false"
                        data-r-x-medium="3"
                        data-r-x-medium-nav="true"
                        data-r-x-medium-dots="false"
                        data-r-small="4"
                        data-r-small-nav="true"
                        data-r-small-dots="false"
                        data-r-medium="5"
                        data-r-medium-nav="true"
                        data-r-medium-dots="false"
                        data-r-large="6"
                        data-r-large-nav="true"
                        data-r-large-dots="false">  
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-2.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                           <img src="<?php echo BASEURL;?>assets/images/partner-4.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-5.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-6.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-1.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-7.jpg" alt="">
                        </div>
                        <div class="brand-area-box">
                            <img src="<?php echo BASEURL;?>assets/images/partner-8.jpg" alt="">
                        </div>                        
                    </div> 
                </div>  
            </div>  
            <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
		<script>!function(){var t;if(t=window.driftt=window.drift=window.driftt||[],!t.init)return t.invoked?void(window.console&&console.error&&console.error("Drift snippet included twice.")):(t.invoked=!0,t.methods=["identify","config","reset","track","debug","show","ping","page","hide","off","on"],t.factory=function(e){return function(){var n;return n=Array.prototype.slice.call(arguments),n.unshift(e),t.push(n),t;};},t.methods.forEach(function(e){t[e]=t.factory(e);}),t.load=function(t){var e,n,o,i;e=3e5,i=Math.ceil(new Date()/e)*e,o=document.createElement("script"),o.type="text/javascript",o.async=!0,o.crossorigin="anonymous",o.src="https://js.driftt.com/include/"+i+"/"+t+".js",n=document.getElementsByTagName("script")[0],n.parentNode.insertBefore(o,n);});}();drift.SNIPPET_VERSION='0.3.1';drift.load('7s4mmyeyt9vt');</script>
    </body>
</html>