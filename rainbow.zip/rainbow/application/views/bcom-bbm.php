<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | B.Com & BBM</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>B.Com & BBM</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li> B.Com & BBM </li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
				<div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">B.Com & BBM</h2>
									<p>Rainbow institute offers coaching in commerce stream for Bachelor's degree (B.Com & BBM) students. The number of students opting for commerce after 10th has increased exponentially in last few years.</p>
									<p>For the aspirants of Chartered accountant (CA), Company Secretary ship (CS) and Cost & Work Accountancy (ICWA) degrees, Courses like B.Com & BBM could be stepping stones.</p>
									<p>Rainbow focuses on making students understand the importance of accounting which is essential for monitoring and guiding business operations.</p>
									<p>All the subjects of BBM and B.Com will be covered in the 3 months course.</p>
									<p>Study material for B.Com and BBM Students prepared after a thorough research of latest trends, updated syllabus, entrance papers and the level of competition.</p>
									<p>Every class is provided with skilled and well-versed teacher so that students can get the most out of their experience and knowledge</p>
									<p>After end of every chapter, students will be given a short practice test. Regular mock tests also will be conducted. </p>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>B. Com & BBM</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Entrance Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>8 months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>2<sup>nd</sup> PUC / 12<sup>th</sup> Pass Students</td>
															</tr>
															<tr>
																<th>Syllabus Covered</th>
																<td>All Subjects</td>
															</tr>
															<tr>
																<th>Class Commencement</th>
																<td>July 2nd week</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer">
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. HARI PRASAD</h4>
																	<p><em>M.Com., CA-Final</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Accountancy (CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. Pradeep</h4>
																	<p><em>M.Com. , MBA</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>10 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Business Studies</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/female-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Ms. SARASWATHI</h4>
																	<p><em>MA. B.Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Economics(CPT/IPCC)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>															
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">												
															<div class="media-body">
																<h3>Sanu Mendez</h3>
																<p>Excellent coaching center and high tech environment and all teachers are best, and everything is systematic to achive our goal this is the best coaching center.They will conduct monthly test subject wise test its completly Awesome.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">												
															<div class="media-body">
																<h3>Narayana Gowda.S</h3>
																<p>One of the best place to grab knowledge to build our future. I strongly recommend Rainbow tutorials for one’s who aspiring bright career.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>