<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | About Us</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "index";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/crum-bg2.jpg');background-repeat:repeat">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>Privacy Policy</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Privacy Policy</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
			<div class="about-page2-area">
                <div class="container">
					<h2 class="abt-title">Privacy Policy</h2>
				</div>
                <div class="container">
                    <div class="row about-page2-inner">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-justify">
                            <p>Rainbow Institutions values the privacy of its customers. We do not use or disclose information about your visits or any information you may give us, such as your name, address, e-mail identity or telephone number, to any third parties. We do not disclose any personal information to advertisers for marketing and promotional purposes that could be used to personally identify you. This includes your password and other confidential information.</p>
                            <h3>Disclaimers:</h3>
                            <p>We are not responsible for any errors, omissions or representations on any of our pages or on any links on any of our pages. We do not endorse in anyway any advertisers on our web pages. Please verify the veracity of all information on your own before undertaking any purchase, or any transaction, commercial or otherwise with any of the advertisers. The linked sites are not under our control and we are not responsible for the contents of any linked site or any link contained in a linked site, or any changes or updates to such sites. We are providing these links to you only as a convenience, and the inclusion of any link does not imply endorsement by us of the site. We hereby expressly disclaim any implied warranties imputed by the laws of any jurisdiction. We consider ourselves and intend to be subject to the jurisdiction only of the Indian law. We reserve the right to make changes to our site and these disclaimers, terms, and conditions at any time. </p>
						</div>
                    </div>
                </div>
            </div>      
            <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>