<html>
	<head>
	</head>
	<body style="font-family: sans-serif;font-size: 14px;margin:0;padding:0;">
		<center>
			<table style="width:100%;font-family:sans-serif;"> 
				<tr>
					<td>
						<table align="center" width="600" cellpadding="0" cellspacing="0">
							<tr>
								<td align="center"> 
									<a href="<?php echo BASEURL;?>"><img src="<?php echo BASEURL;?>assets/images/logo.png" alt="Rainbow" style="margin: 10px 0px;"></a>
								</td>
							</tr>
							<tr>
								<td style="color: #fff;text-align: center;font-size: 25px;background-color:#000;padding: 20px 0px;">
									<p>Contact Enquiry From Website</p>
								</td>
							</tr>
							<tr>
								<td>
									<table  width="600" cellpadding="0" cellspacing="0" >
										<tr>
											<td style="background-color:#002147;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);" ><p style="text-align: center;color:#fff;font-weight: 600;">Name</p></td>
											<td style="background-color:#86BC42;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);"><p style="font-size: 16px;text-align: center;color:#000"><?php echo $details['name'];?></p></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table  width="600" cellpadding="0" cellspacing="0" >
										<tr>
											<td style="background-color:#002147;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);" ><p style="text-align: center;color:#fff;font-weight: 600;">Email</p></td>
											<td style="background-color:#86BC42;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);text-align: center;"><a href="mailto:<?php echo $details['email'];?>" style="font-size: 16px;text-align: center;color:#000;text-decoration: none;"><?php echo $details['email'];?></a></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table  width="600" cellpadding="0" cellspacing="0" >
										<tr>
											<td style="background-color:#002147;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);" ><p style="text-align: center;color:#fff;font-weight: 600;">Mobile</p></td>
											<td style="background-color:#86BC42;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);text-align: center;"><a href="tel:<?php echo $details['mobile'];?>" style="font-size: 16px;text-align: center;color:#000;text-decoration: none;"><?php echo $details['mobile'];?></a></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table  width="600" cellpadding="0" cellspacing="0" >
										<tr>
											<td style="background-color:#002147;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);" ><p style="text-align: center;color:#fff;font-weight: 600;">Branch</p></td>
											<td style="background-color:#86BC42;padding: 20px 0px;width:50%;border-bottom: 1px dashed rgba(220, 200, 200, 1);"><p style="font-size: 16px;text-align: center;color:#000"><?php echo $details['branch'];?></p></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
									<table  width="600" cellpadding="0" cellspacing="0" >
										<tr>
											<td style="background-color:#002147;padding: 20px 0px;width:50%;" ><p style="text-align: center;color:#fff;font-weight: 600;">Message</p></td>
											<td style="background-color:#86BC42;padding: 20px 0px;width:50%"><p style="font-size: 16px;text-align: center;color:#000"><?php echo $details['message'];?></p></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>