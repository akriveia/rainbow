<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Rainbow | KCET Coaching Classes</title>
    <link href="<?php echo BASEURL;?>ad-assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo BASEURL;?>ad-assets/images/favicon.png">
	<noscript id="deferred-styles">     
		<link href="https://fonts.googleapis.com/css?family=Oswald:400,500,600,700|Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/icon-font.min.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/animate.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/ionicons.min.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/magnific-popup.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/owl.carousel.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/owl.theme.css" rel="stylesheet" type="text/css">
		<link href="<?php echo BASEURL;?>ad-assets/css/custom.css" rel="stylesheet" type="text/css">
    </noscript>
    <script>
      var loadDeferredStyles = function() {
        var addStylesNode = document.getElementById("deferred-styles");
        var replacement = document.createElement("div");
        replacement.innerHTML = addStylesNode.textContent;
        document.body.appendChild(replacement)
        addStylesNode.parentElement.removeChild(addStylesNode);
      };
      var raf = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
          window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
      if (raf) raf(function() { window.setTimeout(loadDeferredStyles, 0); });
      else window.addEventListener('load', loadDeferredStyles);
    </script>
	<link href="<?php echo BASEURL;?>ad-assets/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
		<div class="modal fade" id="myModal" role="dialog" style="background: rgba(0, 0, 0, 0.6);">
			<div class="modal-dialog">
				<div class="col-md-12 col-sm-12 col-xs-12 modal-content p0">
					<div class="col-md-5 col-sm-6 col-xs-12 p0 hidden-xs">
						<img src="<?php echo BASEURL;?>ad-assets/images/popup-banner.png" class="img-responsive">
					</div>
					<div class="col-md-7 col-sm-6 col-xs-12 p0">
						<div class="col-md-12 col-sm-12 col-xs-12 modal-header">
							<button type="button" class="enquire-close close" data-dismiss="modal"><i class="fa fa-times-circle"></i></button>
						</div>
						<div class="col-md-12 col-sm-12 col-xs-12 modal-body call-back">
							<h4 class="text-center mb10">Summer Batches Starting Soon.</h4>
							<h5 class="text-center mb20"><strong>Get Yourself a Seat</strong></h5>
							<form method="POST" action="#" id="popup-form">
								<div class="col-md-12 col-sm-12 col-xs-12 form-group">
									<span class="form-icon"><i class="fa fa-user"></i></span>
									<input class="form-control" type="text" placeholder="Name" name="name"/>
									<span id="name-error" class="error"></span>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 form-group"> 
									<span class="form-icon"><i class="fa fa-phone"></i></span>
									<input class="form-control" type="text" placeholder="Contact" name="mobile"/>
									<span id="mobile-error" class="error"></span>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 form-group">
									<div class="button-mask"></div>
									<input type="button" id="popup-submit" class="btn btn-default pull-right" value="REGISTER NOW"/>
								</div>
							</form>
						</div>
					</div>				
				</div>
			</div>
		</div>
	</div>
    <header id="home" class="welcome-hero-area">
        <div class="header-top-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <div class="logo">
                            <a href="<?php echo BASEURL;?>ppc/kcet-coaching-classes"><img src="<?php echo BASEURL;?>ad-assets/images/logo.png" alt="Rainbow"></a>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-8 col-xs-12">
                        <nav class="navbar navbar-default">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                            </div>
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li><a class="smoth-scroll" href="#home">Home</a></li>
                                    <li><a class="smoth-scroll" href="#aboutus">About Us</a></li>
                                    <li><a class="smoth-scroll" href="#details">Course Details</a></li>
                                    <li><a class="smoth-scroll" href="#testimonial">Testimonials</a></li>
                                    <li><a class="smoth-scroll" href="#contactus">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="home-slider-area">
            <div id="welcome-slide-carousel" class="carousel slide carousel-fade" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <div class="single-slide-item slide-1">
                            <div class="single-slide-item-table">
                                <div class="single-slide-item-table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 col-xs-12 mt0">
												<div class="col-md-12 col-sm-12 col-xs-12 mt0 p0">
													<h2>Coaching Classes for KCET</h2>
												</div>
												<div class="col-md-12 col-sm-12 col-xs-12 mt0 p0">
													<ul class="about-list white-text wow fadeInLeft" data-wow-duration="3s" data-wow-delay="0.5s">
														<li><i class="fa fa-arrow-right"></i>Highly Distinguished Faculty</li>
														<li><i class="fa fa-arrow-right"></i>Regular Revisions & Special Classes</li>
														<li><i class="fa fa-arrow-right"></i>Updated Study Materials - Soft & Hard copies</li>
														<li><i class="fa fa-arrow-right"></i>Progress assessment</li>
														<li><i class="fa fa-arrow-right"></i>Career Counselling</li>
													</ul>
												</div>
											</div>
											<div class="col-md-4 col-sm-4 col-xs-12 slider-form hidden-xs hidden-sm">
												<div class="col-md-12 col-sm-12 col-xs-12 call-back">
													<h3>Summer Batches Starting Soon</h3>
													<h5 class="mb20">Get yourself a Seat</h5>
													<form method="POST" action="#" id="enquiry-form">
														<div class="col-md-12 col-sm-12 col-xs-12 form-group">
															<span class="form-icon"><i class="fa fa-user"></i></span>
															<input class="form-control" name="name" placeholder="Name" type="text">
															<span id="page-name-error" class="error"></span>
														</div>
														<div class="col-md-12 col-sm-12 col-xs-12 form-group">
															<span class="form-icon"><i class="fa fa-phone"></i></span>
															<input class="form-control" name="mobile" placeholder="Contact No" type="text">
															<span id="page-mobile-error" class="error"></span>
														</div>
														<div class="col-md-12 col-sm-12 col-xs-12 form-group">
															<input class="btn btn-default" value="Submit" type="submit" id="save-enquiry">
														</div>
													</form>
												</div>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
				</div>
            </div>
        </div>
    </header>
    <div class="callouts-wrapper hidden-xs">
        <div class="container">
            <div class="row">
                <div class="callouts-inner">
                    <div class="col-md-4 col-sm-6 hidden-sm">
                        <div class="message-description">
                            <div class="row">
                                <div class="col-md-2 col-sm-2 col-xs-2"> <i class="fa fa-map-marker" aria-hidden="true"></i> </div>
                                <div class="col-md-10 col-sm-10 col-xs-10">
                                    <h2>Branches</h2>
                                    <p><a href="#">K R Puram</a></p>
                                    <p><a href="#">Whitefield</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="message-description">
                            <div class="row">
                                <div class="col-md-2 col-sm-2 col-xs-2"> <i class="fa fa-envelope" aria-hidden="true"></i> </div>
                                <div class="col-md-10 col-sm-10 col-xs-10">
                                    <h2>Email Address</h2>
                                    <p><a href="mailto:rainbowtutorials13@gmail.com">rainbowtutorials13@gmail.com</a></p>
                                    <p><a href="mailto:rainbowacademy2014@gmail.com">rainbowacademy2014@gmail.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="message-description">
                            <div class="row">
                                <div class="col-md-2 col-sm-2 col-xs-2"> <i class="fa fa-phone" aria-hidden="true"></i> </div>
                                <div class="col-md-10 col-sm-10 col-xs-10">
                                    <h2>Contact Number</h2>
                                    <p><a href="tel:+91 97315 08686">+91 97315 08686</a></p>
                                    <p><a href="tel:+91 97315 63656">+91 97315 63656</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section id="aboutus" class="aboutus">
        <div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12 visible-xs visible-sm">
					<div class="call-back">
						<h3 class="text-center">Summer Batches Starting Soon</h3>
						<h5 class="text-center mb20">Get yourself a Seat</h5>
						<form method="POST" action="#" id="enquiry-form-2">
							<div class="col-md-12 col-sm-12 col-xs-12 form-group">
								<span class="form-icon"><i class="fa fa-user"></i></span>
								<input class="form-control" name="name" placeholder="Name" type="text">
								<span id="page-name-error-2" class="error"></span>
							</div>
							<div class="col-md-12 col-sm-12 col-xs-12 form-group">
								<span class="form-icon"><i class="fa fa-phone"></i></span>
								<input class="form-control" name="mobile" placeholder="Contact No" type="text">
								<span id="page-mobile-error-2" class="error"></span>
							</div>
							<div class="col-md-12 col-sm-12 col-xs-12 form-group">
								<input class="btn btn-default pull-right" value="Submit" type="submit" id="save-enquiry-2">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
        <div class="container">
            <div class="section-title">
                <h2>About Us</h2>
				<p><span></span></p>
                <span class="line"></span>
			</div>
            <div class="row">
                <div class="about-box">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <h3>Welcome to Rainbow</h3>
                        <p>Rainbow has been implemented with honest dedication and continuous improvement. Thanks to the relentless efforts of our faculty to make the process of learning truly knowledge oriented, now we are one of the most favorite pick for the students and aspirants in the South Region of Bengaluru.</p>
                        <p>Faculty members are passionate and curious individuals who continue their own research while teaching at rainbow institution. They come from excellent teaching background bringing with a bag full of experience and diverse wealth of knowledge.</p>
                        <p>Rainbow has an excellent infrastructure, situated in a calm and tranquil area. Classrooms are well equipped with necessary furniture and are spacious for 50 students. Faculty and students are provided with all the teaching aids such as LCD projectors, microphones, multimedia Computer, audio systems etc.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="details" class="services">
        <div class="container">
			<div class="section-title">
                <h2>Course Details</h2>
				<p><span></span></p>
                <span class="line"></span>
			</div>
			<div class="row">
                <div class="about-box">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <h3>About Karnataka-CET</h3>
                        <p>KCET or karnataka cet is the Karnataka’s common entrance test for engineering and medical aspirants. KEA (Karnataka examination authority) conducts these tests every year. Lakhs of 12th / 2nd PUC students from all over the state appear for the examination. For More details about the exam pattern, eligibility & application form, log on to kea website.</p>
                        <h3>CET Coaching @Rainbow</h3>
                        <p>Better CET ranking means best choices for students. It’ll allow one to pick their choice of college to pursue their graduation in the desired stream. keeping this in mind, we at Rainbow, help students to prepare well for the examination. Our teaching faculty encourages students to truly learn and understand the concept rather than studying just for the sake of good grades.</p>
                        <ul class="about-list">
                            <li><i class="fa fa-arrow-right"></i>Both weekend and weekday batches, with flexible timings</li>
                            <li><i class="fa fa-arrow-right"></i>Our branches now at multiple locations in Bangalore, Near K R Puram and Whitefield</li>
                            <li><i class="fa fa-arrow-right"></i>The focus subjects include Physics, Chemistry, Mathematics and Biology</li>
                            <li><i class="fa fa-arrow-right"></i>Rainbow offers both integrated and crash course.</li>
                            <li><i class="fa fa-arrow-right"></i>12<sup>th</sup> / II PUC students are eligible to attend the classes.</li>
                            <li><i class="fa fa-arrow-right"></i>Highly qualified and experienced faculty.</li>
                            <li><i class="fa fa-arrow-right"></i>We regularly invite guest lecturers from reputed colleges to solve previous years’ question papers for you.</li>
                            <li><i class="fa fa-arrow-right"></i>Best infrastructure facilities to conduct the classes.</li>
                            <li><i class="fa fa-arrow-right"></i>The respective teacher of the subject will conduct regular mock tests.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="testimonial" class="testimonials">
        <div class="container">
            <div class="section-title">
                <h2>Student Testimonials</h2>
				<p><span></span></p>
				<span class="line"></span>
			</div>
            <div id="testimonials" class="owl-carousel owl-theme">
                <div class="item">
                    <div class="tes-wrapper">
                        <h3>Bhuvan<span>II PUC Science</span></h3>
                        <p>For sure Rainbow is one of the best institutes I have studied in. Teacher-student bonding is great which really makes learning easier.</p>
                    </div>
                </div>
				<div class="item">
                    <div class="tes-wrapper">
                        <h3>Nagashree<span>K-CET</span></h3>
                        <p>Study materials are very good and easy to understand. I am very happy to be a student of rainbow and i have improved a lot in studies</p>
                    </div>
                </div>
				<div class="item">
                    <div class="tes-wrapper">
                        <h3>Shamitha<span>II PUC Science</span></h3>
                        <p>Coaching is nice. study materials are excellent and easy to understand. Best coaching center for 2nd PUC competitive and regular courses.</p>
                    </div>
                </div>
				<div class="item">
                    <div class="tes-wrapper">
                        <h3>Vinay Prasad<span>K-CET</span></h3>
                        <p>Rainbow has fully pledged lecturers who are very much dedicated to improvise the students knowledge in this competitive environment.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="contactus" class="contactus">
        <div class="container">
            <div class="row">
                <div class="section-title">
                    <h2>Contact <span>Us</span></h2>
                    <p><span></span></p>
                    <span class="line"></span>
				</div>
                <div class="col-md-12 col-sm-12">
                    <div class="contact-info">
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class="single-contact"> <i class="lnr lnr-phone"></i>
                                <h4>Phone</h4>
                                <p><a href="tel:+91 97315 08686">+91 97315 08686</a></p>
								<p><a href="tel:+91 97315 63656">+91 97315 63656</a></p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="single-contact"> <i class="lnr lnr-map-marker"></i>
                                <h4>Address</h4>
                                <p>2<sup>nd</sup> floor, Venkateshwara complex, Devasandra main road, K R Puram - 560036</p>
								<p>#44, Leelavathi Achar Complex, Immadihalli Main Rd , Whitefield - 560066</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class="single-contact"> <i class="lnr lnr-envelope"></i>
                                <h4>Email</h4>
                                <p><a href="mailto:rainbowtutorials13@gmail.com">rainbowtutorials13@gmail.com</a></p>
								<p><a href="mailto:rainbowacademy2014@gmail.com">rainbowacademy2014@gmail.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2015 Rainbow | All Rights Reserved.</p>
        </div>
    </footer>
    <script src="<?php echo BASEURL;?>ad-assets/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript">var baseurl = "<?php echo BASEURL; ?>";</script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/jquery.easing.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/jquery.isotope.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/imagesloaded.pkgd.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/jquery.animateNumber.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/plugins.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/wow.min.js"></script>
    <script type="text/javascript" src="<?php echo BASEURL;?>ad-assets/js/custom.js"></script>
	<!-- Global site tag (gtag.js) - Google AdWords: 827928312 -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-827928312"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'AW-827928312');
	</script>
	<script>
		$(function(){
			$(".form-control").on("keyup",function(){
				$(this).siblings(".error").html("");
			});
			$("#popup-submit").click(function(e) {
				e.preventDefault();
				$(".error").html("");
				$("#popup-submit").attr("disabled", true);
				$.ajax({
					type: "post",
					url: baseurl + "adwords_popup_enquiry",
					data: $("#popup-form").serialize() + '&url=' + location.href + '&course=kcet',
					dataType: "json",
					success: function(data) {
						if (data.success == 1) {
							location.href = baseurl + "thank-you"
						} else {
							if (data.error == "name") {
								$("#popup-submit").attr("disabled", false);
								$("#name-error").html("Enter your full name");
							} else if (data.error == "mobile") {
								$("#popup-submit").attr("disabled", false);
								$("#mobile-error").html("Invalid mobile number");
							} else if (data.error == "failed") {
								$("#popup-submit").attr("disabled", false);
								alert("Unable to submit your deatils. Please contact us.");
							}
						}
					}
				});
			});
			$("#save-enquiry").click(function(e) {
				e.preventDefault();
				$(".error").html("");
				$("#save-enquiry").attr("disabled", true);
				$.ajax({
					type: "post",
					url: baseurl + "adwords_page_enquiry",
					data: $("#enquiry-form").serialize() + '&url=' + location.href + '&course=kcet',
					dataType: "json",
					success: function(data) {
						if (data.success == 1) {
							location.href = baseurl + "thank-you"
						} else {
							if (data.error == "name") {
								$("#save-enquiry").attr("disabled", false);
								$("#page-name-error").html("Enter your full name");
							} else if (data.error == "mobile") {
								$("#save-enquiry").attr("disabled", false);
								$("#page-mobile-error").html("Invalid mobile number");
							} else if (data.error == "failed") {
								$("#save-enquiry").attr("disabled", false);
								alert("Unable to submit your deatils. Please contact us.");
							}
						}
					}
				});
			});
			$("#save-enquiry-2").click(function(e) {
				e.preventDefault();
				$(".error").html("");
				$("#save-enquiry-2").attr("disabled", true);
				$.ajax({
					type: "post",
					url: baseurl + "adwords_page_enquiry",
					data: $("#enquiry-form-2").serialize() + '&url=' + location.href + '&course=kcet',
					dataType: "json",
					success: function(data) {
						if (data.success == 1) {
							location.href = baseurl + "thank-you"
						} else {
							if (data.error == "name") {
								$("#save-enquiry-2").attr("disabled", false);
								$("#page-name-error-2").html("Enter your full name");
							} else if (data.error == "mobile") {
								$("#save-enquiry-2").attr("disabled", false);
								$("#page-mobile-error-2").html("Invalid mobile number");
							} else if (data.error == "failed") {
								$("#save-enquiry-2").attr("disabled", false);
								alert("Unable to submit your deatils. Please contact us.");
							}
						}
					}
				});
			});
		});
	</script>
</body>
</html>