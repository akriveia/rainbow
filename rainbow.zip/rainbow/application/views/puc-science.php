<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | I - II PUC Science</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>I - II PUC Science</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>I - II PUC Science</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
                <div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">I - II PUC Science</h2>
									<p>Science stream is the stepping stone for engineering and medical aspirants. New generation students are ambitious & are well aware of what they want to do with their future. We provide such students a strong foundation and assist them in achieving their academic goals. </p>
									<p>We provide coaching for PCMB, PCMC & PCME students of I & II PUC</p>
									<p>Our faculty members have more than 10 years of experience in teaching. Their knowledge and expertise in subjects have helped thousands of students excel academically. </p>
									<p>We offer excellent study material with question banks and solved test papers. </p>
									<p>Teachers conduct chapter wise class tests every week, assess the student's’ performance, personally appraise students about their progress and make sure they are aware of the areas where they need to improve.</p>                           
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>I & II PUC Science</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Entrance Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>10 months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>10<sup>th</sup> and 11<sup>th</sup> passed students</td>
															</tr>
															<tr>
																<th>Syllabus Covered</th>
																<td>PCMB, PCMC, PCME</td>
															</tr>
															<tr>
																<th>Class Commencement</th>
																<td>3rd week of March</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer"> 
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. PRASAD B K</h4>
																	<p><em>M.Sc. , M.Phil</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Physics (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. MANJUNATH S R</h4>
																	<p><em>M.Sc. , M.Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>20 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Chemistry (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. MOHAN B K</h4>
																	<p><em>M.Sc., Ph.D</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>15 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Biology (NEET)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. LAKSHMAN V</h4>
																	<p><em>M.Sc., B. Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Mathematics (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">
															<div class="media-body">
																<h3>Gouthami Yadav</h3>
																<p>It's a colourful place as it's name tell us Rainbow. I had a great experience studying in this institution, my combination was PCMB. All experienced lecturers, the teaching is very professional and I thank all my lecturers for supporting me to score good marks in my board exam. </p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">
															<div class="media-body">
																<h3>Chaitraj Gowda</h3>
																<p>Excellent teaching in rainbow tutorials. Especially science . (PCMB )lectures are too good . They have more year experience . Coaching in that institute is too good and also CET coaching is good.</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include_once('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>