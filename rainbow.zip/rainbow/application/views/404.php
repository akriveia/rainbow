<!doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow  | Page Not Found</title>
		<?php include_once("head-styles.php");?>
    </head>
	<body>
        <div id="wrapper">
			<?php
				$tab = "index";
				include_once("menu.php");
			?>
            <div class="error-page-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="error-top">
                                <img src="<?php echo BASEURL;?>assets/images/404.png" class="img-responsive" alt="404">
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="error-bottom">                                
                                <h2>Sorry!!! Page Was Not Found</h2>
                                <p>The page you are looking is not available or has been removed. Try going to Home Page by using the button below.</p>
                                <a href="<?php echo BASEURL;?>" class="default-white-btn">Go To Home Page</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>