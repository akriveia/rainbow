<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Courses Offered</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/crum-bg.jpg');background-repeat:repeat">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>Courses Offered</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Courses Offered</li>
							</ul>
						</div>
                    </div>
                </div>
            </div>
            <div class="courses-page-area1">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-md-push-3">
                            <div class="row">
                                <div class="tab-content mt0">
                                    <div role="tabpanel" class="tab-pane active" id="gried-view">
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">
											<div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-1.jpg" alt="10th Standard">
														<a href="<?php echo BASEURL;?>tenth-standard"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>tenth-standard">10<sup>th</sup> Standard</a></h3>
														<p class="item-content">10<sup>th</sup> Standard is the career foundation for students and Rainbow is committed to make strong career foundation.</p>
														<a href="<?php echo BASEURL;?>tenth-standard" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
										<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.2s">
											<div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-2.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>puc-science"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>puc-science">I-II PUC Science</a></h3>
														<p class="item-content">Science stream is the stepping stone for engineering and medical aspirants and we provide strong foundation.</p>
														<a href="<?php echo BASEURL;?>puc-science" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
											<div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-3.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>puc-commerce"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>puc-commerce">I-II PUC Commerce</a></h3>
														<p class="item-content">Accounting and finance is the backbone of commerce stream and we create an operational environment for this.</p>
														<a href="<?php echo BASEURL;?>puc-commerce" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.4s">
                                           <div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-4.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>cet"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>cet">NEET/ JEE/ K-CET/ COMED-K</a></h3>
														<p class="item-content">Rainbow helps students to start preparing for Competitive Entrance Test along with their board exam preparations</p>
														<a href="<?php echo BASEURL;?>cet" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                                           <div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-5.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>bcom-bbm"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>bcom-bbm">B.Com & BBM</a></h3>
														<p class="item-content">Rainbow help students to understand the importance of accounting for monitoring and guiding business operations.</p>
														<a href="<?php echo BASEURL;?>bcom-bbm" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.6s">
                                           <div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-6.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>diploma"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>diploma">Diploma</a></h3>
														<p class="item-content">Rainbow coaching and study materials helps diploma students to easily comprehend complex engineering topics.</p>
														<a href="<?php echo BASEURL;?>diploma" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.7s">
                                           <div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-7.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>engineering"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>engineering">Engineering</a></h3>
														<p class="item-content">We provide coaching for Electronics, Mechanical ,Computer science branches and mathematics to all branches.</p>
														<a href="<?php echo BASEURL;?>engineering" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s">
                                           <div class="courses-box1 thumbnail">
                                                <div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-8.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>ca-cpt"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>ca-cpt">CA-CPT</a></h3>
														<p class="item-content">Rainbow has an excellent career oriented coaching for CA-CPT along with certificate and placement assistance</p>
														<a href="<?php echo BASEURL;?>ca-cpt" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.9s">
                                           <div class="courses-box1 thumbnail">
												<div class="single-item-wrapper">
													<div class="courses-img-wrapper hvr-bounce-to-right">
														<img class="img-responsive" src="<?php echo BASEURL;?>assets/images/course-9.jpg" alt="courses">
														<a href="<?php echo BASEURL;?>cs-cma"><i class="fa fa-link" aria-hidden="true"></i></a>
													</div>
													<div class="courses-content-wrapper">
														<h3 class="item-title"><a href="<?php echo BASEURL;?>cs-cma">CS-CMA</a></h3>
														<p class="item-content">Rainbow has an excellent career oriented coaching for CA-CPT along with certificate and placement assistance</p>
														<a href="<?php echo BASEURL;?>cs-cma" class="btn btn-md btn-info readmore-btn pull-right">Enroll Now</a>
													</div>
												</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 col-md-pull-9">
                            <div class="sidebar">
                                <div class="sidebar-box">
									<div class="sidebar-box-inner">
										<h3 class="sidebar-title">Enroll Now !!!</h3>
										<div class="sidebar-question-form"> 
											<form action="<?php echo BASEURL;?>save-enquiry" method="post" id="side-enquiry-form">
												<fieldset>
													<div class="form-group">
														<span><i class="fa fa-user"></i></span>
														<input type="text" placeholder="Name*" class="form-control" name="name">
													</div>
													<div class="form-group">
														<span><i class="fa fa-envelope"></i></span>
														<input type="email" placeholder="Email*" class="form-control" name="email">
													</div>
													<div class="form-group">
														<span><i class="fa fa-phone"></i></span>
														<input type="email" placeholder="Mobile*" class="form-control" name="mobile">
													</div>
													<div class="form-group">
														<span style="height:100%;padding-top:10%;"><i class="fa fa-comment"></i></span>
														<textarea placeholder="Message" class="textarea form-control" name="message" rows="3" cols="20" style="resize:none"></textarea>
													</div>
													<div class="col-md-12 col-xs-12 p0">
														<label id="form-error"></label>
														<div class="button-mask"></div>
														<input type="submit" id="enquiry-now" value="Submit" class="default-full-width-btn"/>
													</div>
												</fieldset>
											</form>
										</div>
									</div>
								</div>
                                <div class="sidebar-box">
                                    <div class="sidebar-box-inner">
                                        <h3 class="sidebar-title">Other Departments</h3>
                                        <div class="sidebar-latest-research-area">
                                            <ul>
                                                <li id="sci-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>science-department">
														<img src="<?php echo BASEURL;?>assets/images/sci-dept.jpg" class="img-responsive img-thumbnail" alt="Science"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>science-department"><h4>Science Department</h4></a>
                                                    </div>
                                                </li>
                                                <li id="comm-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>commerce-department">
														<img src="<?php echo BASEURL;?>assets/images/comm-dept.jpg" class="img-responsive img-thumbnail" alt="Commerce"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>commerce-department"><h4>Commerce Department</h4></a>
                                                    </div>
                                                </li>
                                                <li id="tenth-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>tenth-standard-department">
														<img src="<?php echo BASEURL;?>assets/images/course-1.jpg" class="img-responsive img-thumbnail" alt="Tenth"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                         <a href="<?php echo BASEURL;?>tenth-standard-department"><h4>Tenth Department</h4></a>
                                                    </div>
                                                </li>
												<li id="eng-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>engineering-department">
														<img src="<?php echo BASEURL;?>assets/images/eng-dept.jpg" class="img-responsive img-thumbnail" alt="Technical"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>engineering-department"><h4>Engineering & Diploma</h4></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>