<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Contact Us</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "contact";
				include_once("menu.php");
			?>
            <div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 mb10">
							<h2>Contact Us</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Contact Us</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="contact-us-page1-area">
                <div class="container">
                    <div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 course-details-tab-area">
								<ul class="course-details-tab-btn">
									<li class="active"><a href="#features" data-toggle="tab" aria-expanded="false">K R Puram</a></li>
									<li><a href="#lecturers" data-toggle="tab" aria-expanded="false">Whitefield</a></li>
								</ul>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 tab-content">
									<div class="tab-pane fade active in" id="features">
										<div class="col-lg-8 col-md-7 col-sm-6 col-xs-12">
											<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.454115810937!2d77.69652091425262!3d13.006728090832842!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1107ee383f1d%3A0xafe3b6be2e8fe16b!2sRainbow+Tutorials!5e0!3m2!1sen!2sin!4v1504368413686" width="100%" height="435" frameborder="0" style="border:1px solid #bdbdbd" allowfullscreen></iframe>
										</div>									
										<div class="col-lg-4 col-md-5 col-sm-6 col-xs-12">
											<div class="contact-us-info1">   
												<ul>
													<li>
														<i class="mt30 fa fa-map-marker" aria-hidden="true"></i>
														<h3>Address</h3>
														<p>2nd floor, Venkateshwara complex,</br> Devasandra main road, </br>Near GEETHA clinic, K R Puram,<br>Bengaluru - 560036</p>
													</li>
													<li>
														<i class="fa fa-phone" aria-hidden="true"></i>
														<h3>Phone</h3>
														<p><a href="tel:97315 08686">97315 08686</a> </p>   
													</li>
													<li>
														<i class="fa fa-envelope-o" aria-hidden="true"></i>
														<h3>E-mail</h3>
														<p><a href="mailto:rainbowtutorials13@gmail.com">rainbowtutorials13@gmail.com</a></p>   
													</li>
													<li>
														<h3>Follow Us</h3>
														<ul class="contact-social mt10">
															<li><a target="_blank" href="https://www.facebook.com/rainbowinstitutions"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
															<li><a target="_blank" href="https://www.linkedin.com/company/rainbow-institutions"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
															<li><a target="_blank" href="https://plus.google.com/+RainbowTutorialsBengaluru"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
														</ul>
													</li>       
												</ul>
											</div>  
										</div>
									</div>
									<div class="tab-pane fade" id="lecturers">
										<div class="col-lg-8 col-md-7 col-sm-6 col-xs-12">
											<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.042520834836!2d77.75246731425207!3d12.969130990857524!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae0dfb6285cedd%3A0x1f64f1d679922d1d!2sRainbow+Academy!5e0!3m2!1sen!2sin!4v1504369474246" width="100%" height="435" frameborder="0" style="border:1px solid #bdbdbd" allowfullscreen></iframe>
										</div>
										<div class="col-lg-4 col-md-5 col-sm-6 col-xs-12">
											<div class="contact-us-info1">   
												<ul>
													<li>
														<i class="fa fa-map-marker" aria-hidden="true"></i>
														<h3>Address</h3>
														<p>#44, Leelavathi Achar Complex</br>Immadihalli Main Rd,</br>Near RAM Mandir, Whitefield, <br> Bengaluru - 560066</p>
													</li>
													<li>
														<i class="fa fa-phone" aria-hidden="true"></i>
														<h3>Phone</h3>
														<p><a href="tel:97315 63656">97315 63656</a></p>   
													</li>
													<li>
														<i class="fa fa-envelope-o" aria-hidden="true"></i>
														<h3>E-mail</h3>
														<p><a href="mailto:rainbowacademy2014@gmail.com">rainbowacademy2014@gmail.com</a></p>   
													</li>
													<li>
														<h3>Follow Us</h3>
														<ul class="contact-social mt10">
															<li><a target="_blank" href="https://www.facebook.com/Rainbow-Academy-at-whitefield-801104206645753"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
															<li><a target="_blank" href="https://www.linkedin.com/company/rainbow-institutions"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
															<li><a target="_blank" href="https://plus.google.com/+RainbowAcademyBengaluru"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
														</ul>
													</li>       
												</ul>
											</div>  
										</div>
									</div>
								</div>
							</div>
						</div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <h2 class="title-default-left title-bar-high">Contact With Us</h2>    
                                </div>  
                            </div>  
                            <div class="row">
                                <div class="contact-form1"> 
                                    <form id="contact-form" action="#" method="post">
                                        <fieldset>
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
													<div class="form-group">
														<span><i class="fa fa-user"></i></span>
														<input type="text" placeholder="Name *" class="form-control" name="name"/>
													</div>
												</div>
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
													<div class="form-group">
														<span><i class="fa fa-envelope"></i></span>
														<input type="email" placeholder="Email *" class="form-control" name="email" />
													</div>
												</div>
                                            </div>
											<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
													<div class="form-group">
														<span><i class="fa fa-phone"></i></span>
														<input type="text" placeholder="Mobile *" class="form-control" name="mobile" />
													</div>
												</div>
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
													<div class="form-group">
														<span><i class="fa fa-map-marker"></i></span>
														<select class="form-control" name="branch">
															<option value="">Choose Branch</option>
															<option value="K R Puram">K R Puram</option>
															<option value="Whitefield">Whitefield</option>
														</select>
													</div>
												</div>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                                <div class="form-group">
													<span style="height:113px;padding-top:40px;"><i class="fa fa-comment"></i></span>
                                                    <textarea placeholder="Enter your message" class="textarea form-control" name="message" style="height:113px"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<div class="col-lg-8 col-md-8 col-sm-6 col-sm-12 p0">
													<label id="form-error"></label>
												</div>
												<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 p0">
													<div class="button-mask"></div>
													<div class="form-group margin-bottom-none">
														<input type="submit" id="submit-contact" class="view-all-primary-btn pull-right" value="Send Message">
													</div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>