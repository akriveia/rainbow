<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | NEET / JEE / K-CET / COMED-K</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>NEET / JEE / K-CET / COMED-K</h2>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>NEET / JEE / K-CET / COMED-K</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
                <div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0 text-justify">
									<h2 class="title-default-left title-bar-high">PUC + NEET / JEE / K-CET / COMED-K</h2>
									<p>Rainbow provides an opportunity for students to start preparing for Competitive entrance test (NEET / JEE / K-CET / COMED-K) along with their board exam preparations. This parallel study system allows students plenty of time to prepare well for both board exams as well as Competitive.</p>
									<p>Institute is well equipped with necessary facilities for theoretical and practical learning of the subjects. Faculty members will be personally involved in designing study schedule for students.</p>
									<p>Students will learn the techniques of solving problems in quick time which will prove to be handy for them in Competitive exams.</p>
									<p>Audio lectures, subject notes, question banks and solved test papers will be provided to every student.</p>
									<p>Weekly revisions, mock tests and topic discussions will be conducted to ensure better preparation.</p>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
									<div class="course-details-tab-area">
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<ul class="course-details-tab-btn">
												<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
												<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
												<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
											</ul>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
											<div class="tab-content">
												<div class="tab-pane fade active in p10" id="description">
													<h3 class="sidebar-title">Course Description</h3>
													<table class="table table-bordered table-reponsive table-hover text-center">
														<thead>
															<th></th>
															<th>PUC + NEET / JEE / K-CET / COMED-K</th>														
														</thead>
														<tbody>
															<tr>
																<th>Admission Mode</th>
																<td>Entrance Test</td>
															</tr>
															<tr>
																<th>Course Duration</th>
																<td>10 months</td>
															</tr>
															<tr>
																<th>Eligibility</th>
																<td>11<sup>th</sup> passed students</td>
															</tr>
															<tr>
																<th>Course Type</th>
																<td>Crash Course, Integrated</td>
															</tr>
															<tr>
																<th>Class Commencement</th>
																<td>3rd week of March</td>
															</tr>
														</tbody>
													</table>
												</div>
												<div class="tab-pane fade p10" id="lecturer"> 
													<h3 class="sidebar-title">Course Faculty</h3>
													<div class="course-details-skilled-lecturers">
														<ul>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. PRASAD B K</h4>
																	<p><em>M.Sc. , M.Phil</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Physics (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. MANJUNATH S R</h4>
																	<p><em>M.Sc. , M.Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>20 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Chemistry (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. MOHAN B K</h4>
																	<p><em>M.Sc., Ph.D</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>15 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Biology (NEET)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li>
															<li>
																<div class="skilled-lecturers-img">
																	<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
																</div>
																<div class="skilled-lecturers-content">
																	<h4>Mr. LAKSHMAN V</h4>
																	<p><em>M.Sc., B. Ed</em></p>
																</div>   
																<div class="skilled-lecturers-schedule">
																	<ul>
																		<li>
																			<h4>Experience</h4>
																			<p>12 Years</p>
																		</li>
																		<li>
																			<h4>Specialization</h4>
																			<p>Mathematics (NEET/IIT-JEE)</p>
																		</li>
																	</ul>
																</div>
																<div class="skilled-lecturers-details">
																	<a href="#" class="details-accent-btn">Details</a>
																</div>
															</li> 
														</ul>
													</div>
												</div>
												<div class="tab-pane fade p10" id="reviews">
													<div class="course-details-comments">
														<h3 class="sidebar-title">Student Reviews</h3>
														<div class="media">												
															<div class="media-body">
																<h3>Hema Latha</h3>
																<p>Excellent coaching wit qualified teachers. one f the best tutorial. I suggest evry1 to join here all the best.....</p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
														<div class="media">												
															<div class="media-body">
																<h3>Uday</h3>
																<p>It was good and a new experience which I felt in this tution. Met few friends had fun and at the same time we all also concentrated on studies and about the tutions facilities and service are satisfactory. thank you RAINBOW </p>
																<div class="replay-area">
																	<ul>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																		<li><i class="fa fa-star" aria-hidden="true"></i></li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>										
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<?php include_once('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>