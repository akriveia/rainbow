<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Tenth Standard Department</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "depart";
				include_once("menu.php");
			?>
            <div class="inner-page-banner-area" style="background-image:url('<?php echo BASEURL;?>assets/images/dept-tenth.jpg');padding:100px 0">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2 style="font-size:35px">Tenth Standard Department</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Tenth Standard Department</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="research-details-page-area">
                <div class="container">
                    <div class="row"> 
                        <div class="col-lg-9 col-md-9 col-sm-6 col-xs-12">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
								<div class="research-details-inner text-justify">
									<h2 class="title-default-left title-bar-high">Tenth Standard Department</h2>
									<p>The Department aims to equip children with specified knowledge, skills and values to enable them to become good human beings and productive, socially responsible citizens and to achieve excellence in whatever they do.</p>
									<p>Rainbow’s department of 10th standard constitutes of 8 highly qualified faculty members who possess the required knowledge and experience. Department’s responsibilities involve developing teaching methodologies, implementing these methods effectively, preparing study materials and so on. Students will have access to faculty members anytime of working hours.</p>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p0">
								<div class="lecturers-page1-area">  
									<h2 class="title-default-left title-bar-high">Our Skilled Lecturers</h2>   
									<div class="rc-carousel"
										data-loop="true"
										data-items="3"
										data-margin="30"
										data-autoplay="true"
										data-autoplay-timeout="10000"
										data-smart-speed="2000"
										data-dots="false"
										data-nav="true"
										data-nav-speed="false"
										data-r-x-small="1"
										data-r-x-small-nav="true"
										data-r-x-small-dots="false"
										data-r-x-medium="2"
										data-r-x-medium-nav="true"
										data-r-x-medium-dots="false"
										data-r-small="2"
										data-r-small-nav="true"
										data-r-small-dots="false"
										data-r-medium="3"
										data-r-medium-nav="true"
										data-r-medium-dots="false"
										data-r-large="3"
										data-r-large-nav="true"
										data-r-large-dots="false"> 
										<div class="single-item">
											<div class="lecturers1-item-wrapper">
												<div class="lecturers-img-wrapper">
													<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/1.jpg" alt="team"></a>
												</div>
												<div class="lecturers-content-wrapper">
													<h3 class="item-title"><a href="#">Rosy Janner</a></h3>
													<span class="item-designation">Senior Finance Lecturer</span>
													<ul class="lecturers-social">
														<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
													</ul>
												</div>
											</div>                            
										</div>
										<div class="single-item">
											<div class="lecturers1-item-wrapper">
												<div class="lecturers-img-wrapper">
													<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/2.jpg" alt="team"></a>
												</div>
												<div class="lecturers-content-wrapper">
													<h3 class="item-title"><a href="#">Mike Hussy</a></h3>
													<span class="item-designation">Senior Finance Lecturer</span>
													<ul class="lecturers-social">
														<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
													</ul>
												</div>                            
											</div>
										</div>
										<div class="single-item">
											<div class="lecturers1-item-wrapper">
												<div class="lecturers-img-wrapper">
													<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/3.jpg" alt="team"></a>
												</div>
												<div class="lecturers-content-wrapper">
													<h3 class="item-title"><a href="#">Rosy Janner</a></h3>
													<span class="item-designation">Senior Finance Lecturer</span>												
													<ul class="lecturers-social">
														<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
										<div class="single-item">
											<div class="lecturers1-item-wrapper">
												<div class="lecturers-img-wrapper">
													<a href="#"><img class="img-responsive" src="<?php echo BASEURL;?>assets/img/team/4.jpg" alt="team"></a>
												</div>
												<div class="lecturers-content-wrapper">
													<h3 class="item-title"><a href="#">Rosy Janner</a></h3>
													<span class="item-designation">Senior Finance Lecturer</span>												
													<ul class="lecturers-social">
														<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
														<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
                        </div>
                        <?php include("other-depart.php");?>
                    </div>
                </div>
            </div>			
            <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
		<script>
			$(function(){
				$("#tenth-deprt").hide();
			});
		</script>
    </body>
</html>