<script src="<?php echo BASEURL;?>assets/js/jquery-2.2.4.min.js" type="text/javascript"></script>
		<script type="text/javascript">var baseurl = "<?php echo BASEURL; ?>";</script>
		<script src="<?php echo BASEURL;?>assets/js/modernizr-2.8.3.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/plugins.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/bootstrap.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/wow.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.nivo.slider.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/home.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.meanmenu.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.scrollUp.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.counterup.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/waypoints.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.countdown.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/isotope.pkgd.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/select2.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.marquee.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/jquery.nicescroll.min.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/main.js" type="text/javascript"></script>
		<script src="<?php echo BASEURL;?>assets/js/custom.js" type="text/javascript"></script>
		<!-- Global site tag (gtag.js) - Google AdWords: 827928312 -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=AW-827928312"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'AW-827928312');
		</script>
