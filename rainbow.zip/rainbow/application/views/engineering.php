<!Doctype html>
<html class="no-js" lang="">
	<head>
        <title>Rainbow | Engineering</title>
        <?php include_once("head-styles.php");?>
    </head>
    <body>
        <div id="wrapper">           
            <?php
				$tab = "courses";
				include_once("menu.php");
			?>
			<div class="inner-page-banner-area">
                <div class="container">
                    <div class="pagination-area">
						<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12 p0 mb10">
							<h2>Engineering</h2>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mt10 text-center">
							<ul class="text-center">
								<li><a href="<?php echo BASEURL;?>">Home</a> / </li>
								<li>Engineering</li>
							</ul>
						</div>
                    </div>
                </div>  
            </div>
            <div class="courses-page-area5">
				<div class="container">
                    <div class="row">
						<div class="course-details-inner">
							<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
								<h2 class="title-default-left title-bar-high">Engineering</h2>
								<p>Unfortunately, a lot of engineering colleges these days seems to have ignored the importance of understanding the subject and concentrated just on teaching students how to secure marks. This is really hurting the knowledge based learning. But, thanks to institutes like Rainbow where acquiring knowledge is priority and promoted. </p>
								<p>We provide coaching to engineering students belonging to Electronics, Mechanical and Computer science branches. Also, we teach mathematics to students belonging to any engineering branch.</p>
								<p>At the end of every chapter study materials will be handed over to students. There will be class tests every week conducted by subject teachers.</p>
								<p>Go through the below table for course details.</p>								
							</div>
							<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
								<?php include('side-enquiry.php');?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="course-details-inner p0">
							<div class="course-details-tab-area mt0">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<ul class="course-details-tab-btn">
										<li class="active"><a href="#description" data-toggle="tab" aria-expanded="false">Description</a></li>
										<li><a href="#lecturer" data-toggle="tab" aria-expanded="false">Faculty</a></li>
										<li><a href="#reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
									</ul>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="tab-content">
										<div class="tab-pane fade active in p10 table-responsive" id="description">
											<h3 class="sidebar-title">Course Description</h3>
											<table class="table table-bordered table-hover text-center">
												<thead>
													<th></th>
													<th>Mathematics</th>														
													<th>Electronics</th>														
													<th>Mechanical</th>														
													<th>Computer Science</th>														
												</thead>
												<tbody>						
													<tr>
														<th>Course Duration</th>
														<td>3 Months</td>
														<td>3 Months</td>
														<td>3 Months</td>
														<td>3 Months</td>
													</tr>
													<tr>
														<th>Eligibility</th>
														<td>12<sup>th</sup> / 2<sup>nd</sup> PUC passed students</td>
														<td>12<sup>th</sup> / 2<sup>nd</sup> PUC passed students</td>
														<td>12<sup>th</sup> / 2<sup>nd</sup> PUC passed students</td>
														<td>12<sup>th</sup> / 2<sup>nd</sup> PUC passed students</td>
													</tr>
													<tr>
														<th>Subjects / Syllabus</th>
														<td>Mathematics I, II, III, IV</td>
														<td>Field Theory, Network Analysis, Signals & Systems, Basic Electronics, Basic Electricals</td>
														<td>ATD/BTD/DOM, CEAD-CAMD/TM, HMT, Strength of Materials, Fluid Mechanics</td>
														<td>Computer Network</td>
													</tr>
												</tbody>
											</table>
										</div>
										<div class="tab-pane fade p10" id="lecturer">
											<h3 class="sidebar-title">Course Faculty</h3>
											<div class="course-details-skilled-lecturers">
												<ul>
													<li>
														<div class="skilled-lecturers-img">
															<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
														</div>
														<div class="skilled-lecturers-content">
															<h4>Dr. Harish</h4>
															<p>Assistant Professor</p>
															<p><em>M.Tech., Ph.D</em></p>
														</div>   
														<div class="skilled-lecturers-schedule">
															<ul>
																<li>
																	<h4>Experience</h4>
																	<p>10 Years</p>
																</li>
																<li>
																	<h4>Specialization</h4>
																	<p>Electronics</p>
																</li>
															</ul>
														</div>
														<div class="skilled-lecturers-details">
															<a href="#" class="details-accent-btn">Details</a>
														</div>
													</li> 
													<li>
														<div class="skilled-lecturers-img">
															<img src="<?php echo BASEURL;?>assets/images/male-icon.jpg" class="img-responsive" alt="">
														</div>
														<div class="skilled-lecturers-content">
															<h4>Dr. Srinivas R</h4>
															<p>Associate Professor</p>
															<p><em>M.Tech., Ph.D</em></p>
														</div>   
														<div class="skilled-lecturers-schedule">
															<ul>
																<li>
																	<h4>Experience</h4>
																	<p>13 Years</p>
																</li>
																<li>
																	<h4>Specialization</h4>
																	<p>Mechanical</p>
																</li>
															</ul>
														</div>
														<div class="skilled-lecturers-details">
															<a href="#" class="details-accent-btn">Details</a>
														</div>
													</li>
													<li>
														<div class="skilled-lecturers-img">
															<img src="<?php echo BASEURL;?>assets/images/female-icon.jpg" class="img-responsive" alt="">
														</div>
														<div class="skilled-lecturers-content">
															<h4>Ms. Sarika</h4>
															<p><em>M.Tech</em></p>
														</div>   
														<div class="skilled-lecturers-schedule">
															<ul>
																<li>
																	<h4>Experience</h4>
																	<p>10 Years</p>
																</li>
																<li>
																	<h4>Specialization</h4>
																	<p>Computer Science </p>
																</li>
															</ul>
														</div>
														<div class="skilled-lecturers-details">
															<a href="#" class="details-accent-btn">Details</a>
														</div>
													</li>															
												</ul>
											</div>
										</div>
										<div class="tab-pane fade p10" id="reviews">
											<div class="course-details-comments">
												<h3 class="sidebar-title">Student Reviews</h3>
												<div class="media">												
													<div class="media-body">
														<h3>Aakash Sridhar</h3>
														<p>Very patient to hear out the students problems and difficulties. They work for the student success. The biggest plus point is they keep repeating the topics again an again, so if you miss any class, you will not be affected.</p>
														<div class="replay-area">
															<ul>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
															</ul>
														</div>
													</div>
												</div>
												<div class="media">												
													<div class="media-body">
														<h3>Chaitra</h3>
														<p>Best place to learn...Well occupied space... Good qualified teachers...High rate of score expected from all students... Importance given for all the students...well trained staff and community...Best coaching center</p>
														<div class="replay-area">
															<ul>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
																<li><i class="fa fa-star" aria-hidden="true"></i></li>
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>										
							</div>
						</div>
					</div>
					<?php include('course-carousel.php');?>
                </div>
            </div>
          <?php include_once("footer.php");?>
        </div>
        <?php include_once("scripts.php");?>
    </body>
</html>