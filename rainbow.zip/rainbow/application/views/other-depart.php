<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="sidebar">
								<div class="sidebar-box">
									<div class="sidebar-box-inner">
										<h3 class="sidebar-title">Enroll Now !!!</h3>
										<div class="sidebar-question-form"> 
											<form action="<?php echo BASEURL;?>save-enquiry" method="post" id="side-enquiry-form">
												<fieldset>
													<div class="form-group">
														<span><i class="fa fa-user"></i></span>
														<input type="text" placeholder="Name*" class="form-control" name="name">
													</div>
													<div class="form-group">
														<span><i class="fa fa-envelope"></i></span>
														<input type="email" placeholder="Email*" class="form-control" name="email">
													</div>
													<div class="form-group">
														<span><i class="fa fa-phone"></i></span>
														<input type="email" placeholder="Mobile*" class="form-control" name="mobile">
													</div>
													<div class="form-group">
														<span style="height:100%;padding-top:10%;"><i class="fa fa-comment"></i></span>
														<textarea placeholder="Message" class="textarea form-control" name="message" rows="3" cols="20" style="resize:none"></textarea>
													</div>
													<div class="col-md-12 col-xs-12 p0">
														<label id="form-error"></label>
														<div class="button-mask"></div>
														<input type="submit" id="enquiry-now" value="Submit" class="default-full-width-btn"/>
													</div>
												</fieldset>
											</form>
										</div>
									</div>
								</div>
                                <div class="sidebar-box hidden">
                                    <div class="sidebar-box-inner">
                                        <h3 class="sidebar-title">Other Departments</h3>
                                        <div class="sidebar-latest-research-area">
                                            <ul>
                                                <li id="sci-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>science-department">
														<img src="<?php echo BASEURL;?>assets/images/sci-dept.jpg" class="img-responsive img-thumbnail" alt="Science"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>science-department"><h4>Science Department</h4></a>
                                                    </div>
                                                </li>
                                                <li id="comm-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>commerce-department">
														<img src="<?php echo BASEURL;?>assets/images/comm-dept.jpg" class="img-responsive img-thumbnail" alt="Commerce"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>commerce-department"><h4>Commerce Department</h4></a>
                                                    </div>
                                                </li>
                                                <li id="tenth-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>tenth-standard-department">
														<img src="<?php echo BASEURL;?>assets/images/course-1.jpg" class="img-responsive img-thumbnail" alt="Tenth"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                         <a href="<?php echo BASEURL;?>tenth-standard-department"><h4>Tenth Department</h4></a>
                                                    </div>
                                                </li>
												<li id="eng-deprt">
                                                    <div class="latest-research-img">
                                                        <a href="<?php echo BASEURL;?>engineering-department">
														<img src="<?php echo BASEURL;?>assets/images/eng-dept.jpg" class="img-responsive img-thumbnail" alt="Technical"></a>
                                                    </div>
                                                    <div class="latest-research-content">
                                                        <a href="<?php echo BASEURL;?>engineering-department"><h4>Engineering & Diploma</h4></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>								
                            </div>
                        </div>                