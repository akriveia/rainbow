<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
	public $user = null;
	public function __construct() {
        parent::__construct();
		parse_str($_SERVER['QUERY_STRING'],$_REQUEST);
        $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        $this->load->helper(array('form', 'url', 'html', 'date', 'file','captcha','inflector','string'));
        $this->load->library(array('session','form_validation','upload','pagination','image_lib','email'));
		$this->load->model('model');
    }
	public function index()
	{
		$this->load->view('home');
	}
	public function test_page()
	{
		$this->session->set_userdata('popup', "filled");
		echo $_SESSION['popup'];
	}
	public function contact_us()
	{
		$this->load->view('contact');
	}
	public function about_us()
	{
		$this->load->view('about');
	}
	public function tenth_standard()
	{
		$this->load->view('10th-std');
	}
	public function puc_science()
	{
		$this->load->view('puc-science');
	}
	public function puc_commerce()
	{
		$this->load->view('puc-commerce');
	}
	public function cet()
	{
		$this->load->view('puc-cet');
	}
	public function bcom_bbm()
	{
		$this->load->view('bcom-bbm');
	}
	public function diploma()
	{
		$this->load->view('diploma');
	}
	public function engineering()
	{
		$this->load->view('engineering');
	}
	public function ca_cpt()
	{
		$this->load->view('ca-cpt');
	}
	public function cs_cma()
	{
		$this->load->view('cs-cma');
	}
	public function science_department()
	{
		$this->load->view('science-dept');
	}
	public function commerce_department()
	{
		$this->load->view('comm-dept');
	}
	public function tenth_standard_department()
	{
		$this->load->view('tenth-dept');
	}
	public function engineering_department()
	{
		$this->load->view('engineering-dept');
	}
	public function courses()
	{
		$this->load->view('courses-list');
	}
	public function departments()
	{
		$this->load->view('dept-list');
	}
	public function page_404()
	{
		$this->load->view('404');
	}
	public function coming_soon()
	{
		$this->load->view('coming-soon');
	}
	public function blog()
	{
		$this->load->view('coming-soon');
	}
	public function news()
	{
		$this->load->view('coming-soon');
	}
	public function events()
	{
		$this->load->view('coming-soon');
	}
	public function gallery()
	{
		$this->load->view('coming-soon');
	}
	public function privacy_policy()
	{
		$this->load->view('privacy-policy');
	}
	public function save_popup_enquiry()
	{
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$status = array();
			$done = true;
			$name = $this->input->post("name");
			$contact = $this->input->post("mobile");
			$course = $this->input->post("course");
			$branch = $this->input->post("branch");
			$url = $this->input->post("url");
			if(empty($name) && empty($contact) && empty($course) && empty($branch))
			{
				$status['error'] = "Please fill all the details.";
				$done = false;
			}
			else
			{
				if(empty($name)||(strlen($name)<3))
				{
					$status['error'] = "Please enter full name";
					$done = false;
				}
				elseif(!preg_match('/^[a-zA-Z .]*$/',$name))
				{
					$status['error'] = 'Please enter a valid name.';
					$done = false;
				}
				elseif(empty($contact))
				{
					$status['error'] = 'Please enter mobile number.';
					$done = false;
				}
				elseif(!preg_match('/^[0-9]{10}$/',$contact))
				{
					$status['error']  = 'Invalid mobile number.';
					$done = false;
				}
				elseif(empty($course))
				{
					$status['error'] = 'Please select a course.';
					$done = false;
				}
				elseif(empty($branch))
				{
					$status['error'] = 'Please select a branch.';
					$done = false;
				}
			}
			if($done)
			{
				$insert = $this->model->save_popup_enquiry($name,$contact,$course,$branch,$url);
				if($insert)
				{
					$this->session->set_userdata('POPUP', "filled");
					$config = Array('mailtype' => 'html');
					$this->email->initialize($config);
					$this->email->set_newline("\r\n");
					$data['details'] = array('name'=>$name,'contact'=>$contact,'course'=>$course,'branch'=>$branch,'url'=>$url);
					$body =$this->load->view('emailer-popup',$data,TRUE);
					$this->email->from('enquiry@rainbowinstitutions.com', 'RAINBOW');
					$this->email->cc('rainbowinstitution@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->bcc('pasodi4marketing@gmail.com');
					if($branch == "Whitefield")
						$this->email->to('rainbowacademy2014@gmail.com');
					else
						$this->email->to('rainbowtutorial13@gmail.com');
					$this->email->subject('Website Popup Enquiry');
					$this->email->message($body);
					$this->email->send();
					$status['success'] = 1;
				}
				else{
					$status['error'] = 'Unable to submit your deatils. Please Try again.';
				}
			}
			echo json_encode($status);
		}
		else{
			redirect(BASEURL);
		}
	}
	public function save_enquiry()
	{
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$status = array();
			$done = true;
			$name = $this->input->post("name");
			$email = $this->input->post("email");
			$mobile = $this->input->post("mobile");
			$message = $this->input->post("message");
			$url = $this->input->post("url");
			if(empty($name) && empty($email) && empty($mobile))
			{
				$status['error'] = "Fill Required Fields.";
				$done = false;
			}
			else
			{
				if(empty($name)||(strlen($name)<3))
				{
					$status['error'] = "Please enter full name";
					$done = false;
				}
				elseif(!preg_match('/^[a-zA-Z .]*$/',$name))
				{
					$status['error'] = 'Please enter a valid name.';
					$done = false;
				}
				elseif(empty($email))
				{
					$status['error'] = 'Please enter your Email-id.';
					$done = false;
				}
				elseif(!preg_match('/^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,4})$/',$email))
				{
					$status['error'] = 'Please enter a valid email-id.';
					$done = false;
				}
				elseif(empty($mobile))
				{
					$status['error'] = 'Please enter mobile number.';
					$done = false;
				}
				elseif(!preg_match('/^[0-9]{10}$/',$mobile))
				{
					$status['error']  = 'Invalid mobile number.';
					$done = false;
				}
			}
			if($done)
			{
				$insert = $this->model->save_enquiry($name,$email,$mobile,$message,$url);
				if($insert)
				{
					$config = Array('mailtype' => 'html');
					$this->email->initialize($config);
					$this->email->set_newline("\r\n");
					$data['details'] = array('name'=>$name,'email'=>$email,'mobile'=>$mobile,'message'=>$message,'url' => $url);
					$body =$this->load->view('emailer-sideform',$data,TRUE);
					$this->email->from('enquiry@rainbowinstitutions.com', 'RAINBOW');
					$this->email->cc('rainbowinstitution@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->bcc('pasodi4marketing@gmail.com');
					$this->email->to('rainbowtutorial13@gmail.com,rainbowacademy2014@gmail.com');
					$this->email->subject('Website Course Enquiry');
					$this->email->message($body);
					$this->email->send();
					$status['success'] = 1;				
				}
				else{
					$status['error'] = 'Unable to submit your deatils. Please Try again.';
				}
			}
			echo json_encode($status);
		}
		else{
			redirect(BASEURL);
		}
	}
	public function save_contact()
	{
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$status = array();
			$done = true;
			$name = $this->input->post("name");
			$email = $this->input->post("email");
			$mobile = $this->input->post("mobile");
			$message = $this->input->post("message");
			$branch = $this->input->post("branch");
			$url = $this->input->post("url");
			if(empty($name) && empty($email) && empty($mobile))
			{
				$status['error'] = "Fill Required Fields.";
				$done = false;
			}
			else
			{
				if(empty($name)||(strlen($name)<3))
				{
					$status['error'] = "Please enter full name";
					$done = false;
				}
				elseif(!preg_match('/^[a-zA-Z .]*$/',$name))
				{
					$status['error'] = 'Please enter a valid name.';
					$done = false;
				}
				elseif(empty($email))
				{
					$status['error'] = 'Please enter your Email-id.';
					$done = false;
				}
				elseif(!preg_match('/^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,4})$/',$email))
				{
					$status['error'] = 'Please enter a valid email-id.';
					$done = false;
				}
				elseif(empty($mobile))
				{
					$status['error'] = 'Please enter mobile number.';
					$done = false;
				}
				elseif(!preg_match('/^[0-9]{10}$/',$mobile))
				{
					$status['error']  = 'Invalid mobile number.';
					$done = false;
				}
				elseif(empty($branch))
				{
					$status['error'] = 'Please choose branch.';
					$done = false;
				}
			}
			if($done)
			{
				$insert = $this->model->save_contact($name,$email,$mobile,$message,$branch,$url);
				if($insert)
				{
					$config = Array('mailtype' => 'html');
					$this->email->initialize($config);
					$this->email->set_newline("\r\n");
					$data['details'] = array('name'=>$name,'email'=>$email,'mobile'=>$mobile,'message'=>$message,'branch' => $branch);
					$body =$this->load->view('emailer-contact',$data,TRUE);
					$this->email->from('enquiry@rainbowinstitutions.com', 'RAINBOW');
					$this->email->cc('rainbowinstitution@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->bcc('pasodi4marketing@gmail.com');
					if($branch == "Whitefield")
						$this->email->to('rainbowacademy2014@gmail.com');
					else
						$this->email->to('rainbowtutorial13@gmail.com');
					$this->email->subject('Website Contact Enquiry');
					$this->email->message($body);
					$this->email->send();
					$status['success'] = 1;				
				}
				else{
					$status['error'] = 'Unable to submit your deatils. Please Try again.';
				}
			}
			echo json_encode($status);
		}
		else{
			redirect(BASEURL);
		}
	}
	public function adwords_page()
	{
		$page = strtolower($this->uri->segment(2, 0));
		if($page == "kcet-coaching-classes")
		{
			$this->load->view("adwords-kcet");
		}
		elseif($page == "neet-coaching-classes")
		{
			$this->load->view("adwords-neet");
		}
		elseif($page == "i-ii-puc-science")
		{
			$this->load->view("adwords-i-ii-puc");
		}
		else{
			redirect(BASEURL);
		}
	}
	public function adwords_popup_enquiry()
	{
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$status = array();
			$done = true;
			$name = $this->input->post("name");
			$mobile = $this->input->post("mobile");
			$url = $this->input->post("url");
			$course = $this->input->post("course");
			if(empty($name)||(strlen($name)<3))
			{
				$status['error'] = "name";
				$done = false;
			}
			elseif(!preg_match('/^[a-zA-Z .]*$/',$name))
			{
				$status['error'] = 'name';
				$done = false;
			}
			elseif(empty($mobile))
			{
				$status['error'] = 'mobile';
				$done = false;
			}
			elseif(!preg_match('/^[0-9]{10}$/',$mobile))
			{
				$status['error']  = 'mobile';
				$done = false;
			}
			if($done)
			{
				$insert = $this->model->save_popup_adwords($name,$mobile,$url,$course);
				if($insert)
				{
					$config = Array('mailtype' => 'html');
					$this->email->initialize($config);
					$this->email->set_newline("\r\n");
					$data['details'] = array('name'=>$name,'mobile'=>$mobile,'url' => $url);
					if($course == "kcet")
					{
						$body = $this->load->view('emailer-kcet',$data,TRUE);
						$subject="Adwords KCET Enquiry";
					}
					if($course == "neet")
					{
						$body = $this->load->view('emailer-neet',$data,TRUE);
						$subject="Adwords NEET Enquiry";
					}
					if($course == "puc-sci")
					{
						$body = $this->load->view('emailer-puc-science',$data,TRUE);
						$subject="Adwords PUC Science Enquiry";
					}
					$this->email->from('enquiry@rainbowinstitutions.com', 'RAINBOW');
					$this->email->cc('rainbowinstitution@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->bcc('pasodi4marketing@gmail.com');
					$this->email->to('rainbowacademy2014@gmail.com,rainbowtutorial13@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->subject($subject);
					$this->email->message($body);
					$this->email->send();
					$status['success'] = 1;				
				}
				else{
					$status['error'] = 'failed';
				}
			}
			echo json_encode($status);
		}
		else{
			redirect(BASEURL);
		}
	}
	public function adwords_page_enquiry()
	{
		if($_SERVER['REQUEST_METHOD'] == "POST")
		{
			$status = array();
			$done = true;
			$name = $this->input->post("name");
			$mobile = $this->input->post("mobile");
			$url = $this->input->post("url");
			$course = $this->input->post("course");
			if(empty($name)||(strlen($name)<3))
			{
				$status['error'] = "name";
				$done = false;
			}
			elseif(!preg_match('/^[a-zA-Z .]*$/',$name))
			{
				$status['error'] = 'name';
				$done = false;
			}
			elseif(empty($mobile))
			{
				$status['error'] = 'mobile';
				$done = false;
			}
			elseif(!preg_match('/^[0-9]{10}$/',$mobile))
			{
				$status['error']  = 'mobile';
				$done = false;
			}
			if($done)
			{
				$insert = $this->model->save_page_adwords($name,$mobile,$url,$course);
				if($insert)
				{
					$config = Array('mailtype' => 'html');
					$this->email->initialize($config);
					$this->email->set_newline("\r\n");
					$data['details'] = array('name'=>$name,'mobile'=>$mobile,'url' => $url);
					if($course == "kcet")
					{
						$body = $this->load->view('emailer-kcet',$data,TRUE);
						$subject="Adwords KCET Enquiry";
					}
					if($course == "neet")
					{
						$body = $this->load->view('emailer-neet',$data,TRUE);
						$subject="Adwords NEET Enquiry";
					}
					if($course == "puc-sci")
					{
						$body = $this->load->view('emailer-puc-science',$data,TRUE);
						$subject="Adwords PUC Science Enquiry";
					}
					$this->email->from('enquiry@rainbowinstitutions.com', 'RAINBOW');
					$this->email->cc('rainbowinstitution@gmail.com');
					$this->email->bcc('pasodi4marketing@gmail.com');
					$this->email->to('rainbowacademy2014@gmail.com,rainbowtutorial13@gmail.com,rainbow.krpuram@gmail.com');
					$this->email->subject($subject);
					$this->email->message($body);
					$this->email->send();
					$status['success'] = 1;				
				}
				else{
					$status['error'] = 'failed';
				}
			}
			echo json_encode($status);
		}
		else{
			redirect(BASEURL);
		}
	}
	public function thank_you()
	{
		$this->load->view('thankyou');
	}
	public function quest_premium_bc()
	{
		$name = $_GET['name'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$cmpy_name = $_GET['company'];
		$no_occ = $_GET['occupants'];
		$city = $_GET['city'];
		$device = $_GET['device'];
		$ip = $_GET['ip'];
		$key = $_GET['key'];
		$placement = $_GET['placement'];
		$source = $_GET['source'];
		$campaign = $_GET['campaign'];
		$url = $_GET['url'];
		$page = $_GET['page'];
		$subject="Contact lead from - ".$source." ".$page." - ".$campaign;
		$body = "Customer Details: \n \n Name:  " .$name." \n Mobile:  " .$mobile." \n Email:  ".$email." \n Company Name: ".$cmpy_name. "\n Number of Occupants: ".$no_occ. "\n City:  " .$city.  "\n Device:  " .$device.  "\n IP Address:  " .$ip.  "\n Keywords:  " .$key. "\n Placement:  " .$placement."";
		$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'Cc: gopal.gowda@questoffices.com' . "\r\n" .
					'Cc: questoffices.com@gmail.com' . "\r\n" .
					'Cc: anand.c@questoffices.com' . "\r\n" .
					'Cc: david.ghosh@questoffices.com' . "\r\n" .
					'Cc: pasodi@akriveiatech.com' . "\r\n" .
					'Cc: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers);
		redirect("http://questoffices.com/ppc/thank-you.php");
	}
	public function quest_virtual_office()
	{
		$name = $_GET['name'];
		$company = $_GET['company'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$occupants = $_GET['occupants'];
		$enquiry = $_GET['enquiry'];
		$campaign = $_GET['campaign'];
		$keyword = $_GET['keyword'];
		$city = $_GET['city'];
		$ip = $_GET['ip'];
		$url = $_GET['url'];
		/* $urldata = parse_url($url, PHP_URL_QUERY); */
		$urldata = $_GET['urldata'];
		if($campaign=="")
		{
			if($city == "Bangalore")
			{
				$subject = "Contact Lead From Google Adwords - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .					
							'CC: gopal.gowda@questoffices.com' . "\r\n" .
							'CC: questoffices.com@gmail.com' . "\r\n" .
							'CC: anand.c@questoffices.com' . "\r\n" .
							'CC: david.ghosh@questoffices.com' . "\r\n" .
							'CC: pasodi@akriveiatech.com' . "\r\n" .
							'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Contact Lead From Google Adwords - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: jayant.jhanb@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: karan.nair@questoffices.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Contact Lead From Google Adwords - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="Remarketing"))
		{
			if($city == "Bangalore")
			{
				$subject = "Google ".$campaign." Enquiry - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: david.ghosh@questoffices.com' . "\r\n" .
					'CC: anand.c@questoffices.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Google ".$campaign." Enquiry - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Google ".$campaign." Enquiry - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="LinkedIn"))
		{
			if($city == "Bangalore")
			{
				$subject = "Contact Lead From Linkedin ".$city." - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
							'CC: gopal.gowda@questoffices.com' . "\r\n" .
							'CC: questoffices.com@gmail.com' . "\r\n" .
							'CC: david.ghosh@questoffices.com' . "\r\n" .
							'CC: anand.c@questoffices.com' . "\r\n" .
							'CC: pasodi@akriveiatech.com' . "\r\n" .
							'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Contact Lead From Linkedin ".$city." - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: jayant.jhanb@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: karan.nair@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Contact Lead From Linkedin ".$city." - Virtual Office";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="Bing"))
		{
			$subject = "Contact Lead From Bing Ads - Virtual Office";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: anand.c@questoffices.com' . "\r\n" .
						'CC: david.ghosh@questoffices.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		$body = " Name:= " .$name." \n company := " .$company." \n Mobile := " .$mobile." \n Email:= ".$email." \n Occupants:= ".$occupants." \n Enquiry:= ".$enquiry." \n IP keyword:= ".$keyword." \n IP Address:= ".$_SERVER['REMOTE_ADDR']." \n City:= ".$city."";
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers);
		redirect("http://questoffices.com/ppc/thankyou_vo.php?".$urldata."");
	}
	public function quest_meeting_rooms()
	{
		$name = $_GET['name'];
		$company = $_GET['company'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$occupants = $_GET['occupants'];
		$enquiry = $_GET['enquiry'];
		$campaign = $_GET['campaign'];
		$keyword = $_GET['keyword'];
		$city = $_GET['city'];
		$ip = $_GET['ip'];
		$url = $_GET['url'];
		$urldata = $_GET['urldata'];
		$body = " Name:= " .$name." \n company := " .$company." \n Mobile := " .$mobile." \n Email:= ".$email." \n Occupants:= ".$occupants." \n Enquiry:= ".$enquiry." \n IP keyword:= ".$keyword." \n IP Address:= ".$_SERVER['REMOTE_ADDR']." \n City:= ".$city."";
		if($campaign=="")
		{
			if($city == "Bangalore")
			{
				$subject = "Contact Lead From Google Adwords - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: anand.c@questoffices.com' . "\r\n" .
						'CC: david.ghosh@questoffices.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Contact Lead From Google Adwords - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: jayant.jhanb@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: karan.nair@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Contact Lead From Google Adwords - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="Remarketing"))
		{
			if($city == "Bangalore")
			{
				$subject = "Google ".$campaign." Enquiry - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .					
							'CC: gopal.gowda@questoffices.com' . "\r\n" .
							'CC: questoffices.com@gmail.com' . "\r\n" .
							'CC: anand.c@questoffices.com' . "\r\n" .
							'CC: david.ghosh@questoffices.com' . "\r\n" .
							'CC: pasodi@akriveiatech.com' . "\r\n" .
							'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Google ".$campaign." Enquiry - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Google ".$campaign." Enquiry - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="LinkedIn"))
		{
			if($city == "Bangalore")
			{
				$subject = "Contact Lead From Linkedin ".$city." - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
							'CC: gopal.gowda@questoffices.com' . "\r\n" .
							'CC: questoffices.com@gmail.com' . "\r\n" .
							'CC: anand.c@questoffices.com' . "\r\n" .
							'CC: david.ghosh@questoffices.com' . "\r\n" .
							'CC: pasodi@akriveiatech.com' . "\r\n" .
							'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if($city == "mumbai")
			{
				$subject = "Contact Lead From Linkedin ".$city." - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: jayant.jhanb@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: karan.nair@questoffices.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
			if(($city == "noida") ||($city == "gurgaon"))
			{
				$subject = "Contact Lead From Linkedin ".$city." - Meeting Rooms";
				$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			}
		}
		if(($campaign=="Bing"))
		{
			$subject = "Contact Lead From Bing Ads - Meeting Rooms";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: anand.c@questoffices.com' . "\r\n" .
						'CC: david.ghosh@questoffices.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers);
		redirect("http://questoffices.com/ppc/thankyou_mo.php?".$urldata."");
	}
	public function quest_service_mumbai()
	{
		$name = $_GET['name'];
		$company = $_GET['company'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$occupants = $_GET['occupants'];
		$enquiry = $_GET['enquiry'];
		$campaign = $_GET['campaign'];
		$keyword = $_GET['keyword'];
		$city = $_GET['city'];
		$ip = $_GET['ip'];
		$url = $_GET['url'];
		$urldata = $_GET['urldata'];
		$body = " Name:= " .$name." \n company := " .$company." \n Mobile := " .$mobile." \n Email:= ".$email." \n Occupants:= ".$occupants." \n Enquiry:= ".$enquiry." \n IP keyword:= ".$keyword." \n IP Address:= ".$_SERVER['REMOTE_ADDR']." \n City:= Mumbai";
		if(($campaign=="CatA") || ($campaign=="Non-CatA") || ($campaign=="OS"))
		{
			$subject = "Contact Lead From Google Adwords - ".$campaign."";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="Remarketing"))
		{
			$subject = "Google ".$campaign." Enquiry";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="International"))
		{
			$subject = "Google ".$campaign." Enquiry";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="LinkedIn"))
		{
			$subject = "Contact Lead From Linkedin Mumbai";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="Bing"))
		{
			$subject = "Contact Lead From Bing Ads";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
					'CC: jayant.jhanb@questoffices.com' . "\r\n" .
					'CC: karan.nair@questoffices.com' . "\r\n" .
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers);
		redirect("http://questoffices.com/ppc/thankyou.php?&page=som&".$urldata."");
	}
	public function quest_service_gurgaon()
	{
		$name = $_GET['name'];
		$company = $_GET['company'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$occupants = $_GET['occupants'];
		$enquiry = $_GET['enquiry'];
		$campaign = $_GET['campaign'];
		$keyword = $_GET['keyword'];
		$city = $_GET['city'];
		$ip = $_GET['ip'];
		$url = $_GET['url'];
		$urldata = $_GET['urldata'];
		$body = " Name:= " .$name." \n company := " .$company." \n Mobile := " .$mobile." \n Email:= ".$email." \n Occupants:= ".$occupants." \n Enquiry:= ".$enquiry." \n IP keyword:= ".$keyword." \n IP Address:= ".$_SERVER['REMOTE_ADDR']." \n City:= ".$city."";
		if(($campaign=="CatA") || ($campaign=="Non-CatA") || ($campaign=="OS")|| ($campaign=="CWS"))
		{
			$subject = "Contact Lead From Google Adwords - ".$campaign."";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="Remarketing"))
		{
			$subject = "Google ".$campaign." Enquiry";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="International"))
		{
			$subject = "Google ".$campaign." Enquiry";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="LinkedIn"))
		{
			$subject = "Contact Lead From Linkedin ".$city."";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		if(($campaign=="Bing"))
		{
			$subject = "Contact Lead From Bing Ads";
			$headers = 'From: noreply@questoffices.com' . "\r\n" .
						'CC: manoj.rajput@questoffices.com' . "\r\n" .
						'CC: gopal.gowda@questoffices.com' . "\r\n" .
						'CC: questoffices.com@gmail.com' . "\r\n" .
						'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
						'CC: pasodi@akriveiatech.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		}
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers);
		redirect("http://questoffices.com/ppc/thankyou.php?&page=sog&".$urldata."");
	}
	public function quest_main_enquiry()
	{
		$name = $_GET['name'];
		$email = $_GET['email'];
		$mobile = $_GET['mobile'];
		$cmpy_name = $_GET['company'];
		$no_occ = $_GET['occupants'];
		$city = $_GET['city'];
		$device = $_GET['device'];
		$ip = $_GET['ip'];
		$key = $_GET['key'];
		$source = $_GET['source'];
		$campaign = $_GET['campaign'];
		$cmp = $_GET['cmp'];
		if($source=="")
		{
			$subject="Quest ".$cmp." Website Enquiry ".$source;
		}
		else{
			$subject="Quest ".$cmp." Website Enquiry for ".$source;
		}
		$body = "Customer Details " . "\n Name:  " .$name." \n Mobile:  " .$mobile." \n Email:  ".$email."\n Company Name: ".$cmpy_name. "\n Number of Occupants: ".$no_occ. "\n City:  " .$city.  "\n Device:  " .$device.  "\n IP Address:  " .$ip.  "\n Keywords:  " .$key;
		$headers = 'From: noreply@questoffices.com' . "\r\n" .					
					'CC: gopal.gowda@questoffices.com' . "\r\n" .
					'CC: questoffices.com@gmail.com' . "\r\n" .
					'CC: anand.c@questoffices.com' . "\r\n" .
					'CC: david.ghosh@questoffices.com' . "\r\n" .
					'CC: pasodi@akriveiatech.com' . "\r\n" .
					'CC: shinoj@nikazaonlinemedia.com' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
		$to="enquiry@questoffices.com";
		@mail($to,$subject,$body, $headers); 
		redirect("http://questoffices.com/thank-you.php");
	}
}
