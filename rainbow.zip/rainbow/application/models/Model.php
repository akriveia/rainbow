<?php ob_start();
	if (!defined('BASEPATH')) exit('No direct script access allowed');
	class Model extends CI_Model 
	{
		var $db;
		function __construct() {
			parent::__construct();
			$this->db = $this->load->database('default', TRUE);
		}
		public function save_popup_adwords($name,$mobile,$url,$course)
		{
			if($course == "kcet")
			{
				$type = 'Adwords KCET Popup';
				$subject="Adwords KCET Enquiry";
			}
			if($course == "neet")
			{
				$type = 'Adwords NEET Popup';
				$subject="Adwords NEET Enquiry";
			}
			if($course == "puc-sci")
			{
				$type = 'Adwords PUC Science Popup';
				$subject="Adwords PUC Science Enquiry";
			}
			$data = array(	'std_name'		=> $name,
							'std_mobile'	=> $mobile,
							'form_type'		=> $type,
							'email_subject'	=> $subject,
							'page_url'		=> $url);
			$this->db->insert('enquiry',$data);
			return($this->db->affected_rows() !=1) ? false:true;
		}
		public function save_page_adwords($name,$mobile,$url,$course)
		{
			if($course == "kcet")
			{
				$type = 'Adwords KCET Page';
				$subject="Adwords KCET Enquiry";
			}
			if($course == "neet")
			{
				$type = 'Adwords NEET Page';
				$subject="Adwords NEET Enquiry";
			}
			if($course == "puc-sci")
			{
				$type = 'Adwords PUC Science Popup';
				$subject="Adwords PUC Science Enquiry";
			}
			$data = array(	'std_name'		=> $name,
							'std_mobile'	=> $mobile,
							'form_type'		=> $type,
							'email_subject'	=> $subject,
							'page_url'		=> $url);
			$this->db->insert('enquiry',$data);
			return($this->db->affected_rows() !=1) ? false:true;
		}
		public function save_popup_enquiry($name,$contact,$course,$branch,$url)
		{
			$data = array(	'std_name'		=> $name,
							'std_mobile'	=> $contact,
							'std_course'	=> $course,
							'std_branch'	=> $branch,
							'form_type'		=> 'popup',
							'email_subject'	=> 'Website Popup Enquiry',
							'page_url'		=> $url);
			$this->db->insert('enquiry',$data);
			return($this->db->affected_rows() !=1) ? false:true;
		}
		public function save_enquiry($name,$email,$mobile,$message,$url)
		{
			$data = array(	'std_name'		=> $name,
							'std_email'		=> $email,
							'std_mobile'	=> $mobile,
							'std_message'	=> $message,
							'form_type'		=> 'sideform',
							'email_subject'	=> 'Website Course Enquiry',
							'page_url'		=> $url);
			$this->db->insert('enquiry',$data);
			return($this->db->affected_rows() !=1) ? false:true;
		}
		public function save_contact($name,$email,$mobile,$message,$branch,$url)
		{
			$data = array(	'std_name'		=> $name,
							'std_email'		=> $email,
							'std_mobile'	=> $mobile,
							'std_message'	=> $message,
							'std_branch'	=> $branch,
							'form_type'		=> 'contactform',
							'email_subject'	=> 'Website Contact Enquiry',
							'page_url'		=> $url);
			$this->db->insert('enquiry',$data);
			return($this->db->affected_rows() !=1) ? false:true;
		}
	}
?>